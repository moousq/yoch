import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Search, Check, EyeOff, Lock as LockIcon } from "lucide-react";
import {
  Camera, Video, Film, Aperture, Focus, ScanLine,
  Mic, Volume2, Headphones, Radio, Speaker,
  Lightbulb, Sun, Moon, Zap, Flashlight,
  Battery, BatteryCharging, BatteryFull, Plug, Cable,
  Smartphone, Tablet, Monitor, Tv, Laptop,
  HardDrive, Cpu, Usb, Wifi,
  Move, Maximize, Minimize, RotateCcw,
  Box, Package, Briefcase, ShoppingBag, Archive,
  Wrench, Settings, Cog,
  Car, Plane, Navigation, Map, Compass,
  User, Users, Star, Heart,
  Folder, File, FileText, Image, Music,
  Clock, Calendar, Timer,
  Shield, Lock, Key, Eye,
  Truck, Send, Download, Upload, Share2,
  Grip, Grid, Layers, Layout,
  Circle, Square, Triangle, Hexagon,
  Disc, Target, Crosshair, Sparkles, Clapperboard, Palette,
  Glasses, CircleDot, Contrast, SlidersHorizontal,
  Backpack, FolderOpen,
  Orbit, RotateCw, Anchor, Locate,
  Bluetooth, Cast, Signal, Router, Podcast,
  Database, Server, Save,
  Scan, Shrink,
  Tent, Mountain, TreePine, Sunrise, CloudSun,
  Gamepad2, Joystick, Hand,
  Scissors, Ruler, PenTool, Brush, Eraser,
  Power, CircuitBoard, Gauge,
  Megaphone, AudioLines, AudioWaveform, Volume1,
  Projector, ScreenShare, Airplay,
  Gem, Crown, Award, Medal, Trophy,
  Flame, Droplet, Wind, Snowflake, Thermometer
} from "lucide-react";

const ICONS = [
  // Камеры и видео
  { name: "Camera", icon: Camera, group: "Камера" },
  { name: "Video", icon: Video, group: "Камера" },
  { name: "Film", icon: Film, group: "Камера" },
  { name: "Aperture", icon: Aperture, group: "Камера" },
  { name: "Focus", icon: Focus, group: "Камера" },
  { name: "ScanLine", icon: ScanLine, group: "Камера" },
  { name: "Clapperboard", icon: Clapperboard, group: "Камера" },
  { name: "Scan", icon: Scan, group: "Камера" },
  
  // Объективы и фильтры
  { name: "CircleDot", icon: CircleDot, group: "Оптика" },
  { name: "Glasses", icon: Glasses, group: "Оптика" },
  { name: "Contrast", icon: Contrast, group: "Оптика" },
  { name: "SlidersHorizontal", icon: SlidersHorizontal, group: "Оптика" },
  { name: "Circle", icon: Circle, group: "Оптика" },
  { name: "Disc", icon: Disc, group: "Оптика" },
  
  // Звук
  { name: "Mic", icon: Mic, group: "Звук" },
  { name: "Volume2", icon: Volume2, group: "Звук" },
  { name: "Volume1", icon: Volume1, group: "Звук" },
  { name: "Headphones", icon: Headphones, group: "Звук" },
  { name: "Radio", icon: Radio, group: "Звук" },
  { name: "Speaker", icon: Speaker, group: "Звук" },
  { name: "Music", icon: Music, group: "Звук" },
  { name: "AudioLines", icon: AudioLines, group: "Звук" },
  { name: "AudioWaveform", icon: AudioWaveform, group: "Звук" },
  { name: "Megaphone", icon: Megaphone, group: "Звук" },
  { name: "Podcast", icon: Podcast, group: "Звук" },
  
  // Свет
  { name: "Lightbulb", icon: Lightbulb, group: "Свет" },
  { name: "Sun", icon: Sun, group: "Свет" },
  { name: "Moon", icon: Moon, group: "Свет" },
  { name: "Zap", icon: Zap, group: "Свет" },
  { name: "Flashlight", icon: Flashlight, group: "Свет" },
  { name: "Sparkles", icon: Sparkles, group: "Свет" },
  { name: "Flame", icon: Flame, group: "Свет" },
  { name: "Sunrise", icon: Sunrise, group: "Свет" },
  
  // Питание
  { name: "Battery", icon: Battery, group: "Питание" },
  { name: "BatteryCharging", icon: BatteryCharging, group: "Питание" },
  { name: "BatteryFull", icon: BatteryFull, group: "Питание" },
  { name: "Plug", icon: Plug, group: "Питание" },
  { name: "Cable", icon: Cable, group: "Питание" },
  { name: "Power", icon: Power, group: "Питание" },
  { name: "CircuitBoard", icon: CircuitBoard, group: "Питание" },
  { name: "Gauge", icon: Gauge, group: "Питание" },
  
  // Мониторы и дисплеи
  { name: "Monitor", icon: Monitor, group: "Мониторы" },
  { name: "Tv", icon: Tv, group: "Мониторы" },
  { name: "Laptop", icon: Laptop, group: "Мониторы" },
  { name: "Tablet", icon: Tablet, group: "Мониторы" },
  { name: "Smartphone", icon: Smartphone, group: "Мониторы" },
  { name: "Projector", icon: Projector, group: "Мониторы" },
  { name: "ScreenShare", icon: ScreenShare, group: "Мониторы" },
  { name: "Airplay", icon: Airplay, group: "Мониторы" },
  
  // Хранение и передача данных
  { name: "HardDrive", icon: HardDrive, group: "Хранение" },
  { name: "Database", icon: Database, group: "Хранение" },
  { name: "Server", icon: Server, group: "Хранение" },
  { name: "Cpu", icon: Cpu, group: "Хранение" },
  { name: "Usb", icon: Usb, group: "Хранение" },
  { name: "Save", icon: Save, group: "Хранение" },
  
  // Связь и беспроводное
  { name: "Wifi", icon: Wifi, group: "Связь" },
  { name: "Bluetooth", icon: Bluetooth, group: "Связь" },
  { name: "Cast", icon: Cast, group: "Связь" },
  { name: "Signal", icon: Signal, group: "Связь" },
  { name: "Router", icon: Router, group: "Связь" },
  
  // Стабилизация / Штативы
  { name: "Move", icon: Move, group: "Стабилизация" },
  { name: "Orbit", icon: Orbit, group: "Стабилизация" },
  { name: "RotateCcw", icon: RotateCcw, group: "Стабилизация" },
  { name: "RotateCw", icon: RotateCw, group: "Стабилизация" },
  { name: "Anchor", icon: Anchor, group: "Стабилизация" },
  { name: "Locate", icon: Locate, group: "Стабилизация" },
  { name: "Crosshair", icon: Crosshair, group: "Стабилизация" },
  { name: "Target", icon: Target, group: "Стабилизация" },
  
  // Грип
  { name: "Grip", icon: Grip, group: "Грип" },
  { name: "Grid", icon: Grid, group: "Грип" },
  { name: "Layers", icon: Layers, group: "Грип" },
  { name: "Layout", icon: Layout, group: "Грип" },
  { name: "Maximize", icon: Maximize, group: "Грип" },
  { name: "Minimize", icon: Minimize, group: "Грип" },
  { name: "Shrink", icon: Shrink, group: "Грип" },
  { name: "Hand", icon: Hand, group: "Грип" },
  
  // Транспортировка
  { name: "Backpack", icon: Backpack, group: "Транспорт" },
  { name: "Box", icon: Box, group: "Транспорт" },
  { name: "Package", icon: Package, group: "Транспорт" },
  { name: "Briefcase", icon: Briefcase, group: "Транспорт" },
  { name: "Archive", icon: Archive, group: "Транспорт" },
  { name: "FolderOpen", icon: FolderOpen, group: "Транспорт" },
  { name: "Truck", icon: Truck, group: "Транспорт" },
  { name: "Car", icon: Car, group: "Транспорт" },
  
  // Инструменты
  { name: "Wrench", icon: Wrench, group: "Инструменты" },
  { name: "Settings", icon: Settings, group: "Инструменты" },
  { name: "Cog", icon: Cog, group: "Инструменты" },
  { name: "Scissors", icon: Scissors, group: "Инструменты" },
  { name: "Ruler", icon: Ruler, group: "Инструменты" },
  { name: "PenTool", icon: PenTool, group: "Инструменты" },
  { name: "Brush", icon: Brush, group: "Инструменты" },
  { name: "Eraser", icon: Eraser, group: "Инструменты" },
  
  // Дроны и экшн-камеры
  { name: "Plane", icon: Plane, group: "Дроны" },
  { name: "Navigation", icon: Navigation, group: "Дроны" },
  { name: "Compass", icon: Compass, group: "Дроны" },
  { name: "Map", icon: Map, group: "Дроны" },
  { name: "Gamepad2", icon: Gamepad2, group: "Дроны" },
  { name: "Joystick", icon: Joystick, group: "Дроны" },
  
  // Аутдор
  { name: "Tent", icon: Tent, group: "Аутдор" },
  { name: "Mountain", icon: Mountain, group: "Аутдор" },
  { name: "TreePine", icon: TreePine, group: "Аутдор" },
  { name: "CloudSun", icon: CloudSun, group: "Аутдор" },
  { name: "Droplet", icon: Droplet, group: "Аутдор" },
  { name: "Wind", icon: Wind, group: "Аутдор" },
  { name: "Snowflake", icon: Snowflake, group: "Аутдор" },
  { name: "Thermometer", icon: Thermometer, group: "Аутдор" },
  
  // Разное
  { name: "Eye", icon: Eye, group: "Разное" },
  { name: "Star", icon: Star, group: "Разное" },
  { name: "Heart", icon: Heart, group: "Разное" },
  { name: "Shield", icon: Shield, group: "Разное" },
  { name: "Key", icon: Key, group: "Разное" },
  { name: "Gem", icon: Gem, group: "Разное" },
  { name: "Crown", icon: Crown, group: "Разное" },
  { name: "Award", icon: Award, group: "Разное" },
  { name: "Medal", icon: Medal, group: "Разное" },
  { name: "Trophy", icon: Trophy, group: "Разное" },
  { name: "Square", icon: Square, group: "Разное" },
  { name: "Hexagon", icon: Hexagon, group: "Разное" },
  { name: "Triangle", icon: Triangle, group: "Разное" },
  { name: "Palette", icon: Palette, group: "Разное" },
];

const COLORS = [
  // Синие оттенки
  { name: "Blue", bg: "bg-blue-100", text: "text-blue-700", preview: "bg-blue-500" },
  { name: "Indigo", bg: "bg-indigo-100", text: "text-indigo-700", preview: "bg-indigo-500" },
  { name: "Violet", bg: "bg-violet-100", text: "text-violet-700", preview: "bg-violet-500" },
  { name: "Sky", bg: "bg-sky-100", text: "text-sky-700", preview: "bg-sky-500" },
  { name: "Cyan", bg: "bg-cyan-100", text: "text-cyan-700", preview: "bg-cyan-500" },
  
  // Пурпурные и розовые
  { name: "Purple", bg: "bg-purple-100", text: "text-purple-700", preview: "bg-purple-500" },
  { name: "Fuchsia", bg: "bg-fuchsia-100", text: "text-fuchsia-700", preview: "bg-fuchsia-500" },
  { name: "Pink", bg: "bg-pink-100", text: "text-pink-700", preview: "bg-pink-500" },
  { name: "Rose", bg: "bg-rose-100", text: "text-rose-700", preview: "bg-rose-500" },
  
  // Красные и оранжевые
  { name: "Red", bg: "bg-red-100", text: "text-red-700", preview: "bg-red-500" },
  { name: "Orange", bg: "bg-orange-100", text: "text-orange-700", preview: "bg-orange-500" },
  { name: "Amber", bg: "bg-amber-100", text: "text-amber-700", preview: "bg-amber-500" },
  { name: "Yellow", bg: "bg-yellow-100", text: "text-yellow-700", preview: "bg-yellow-500" },
  
  // Зеленые
  { name: "Lime", bg: "bg-lime-100", text: "text-lime-700", preview: "bg-lime-500" },
  { name: "Green", bg: "bg-green-100", text: "text-green-700", preview: "bg-green-500" },
  { name: "Emerald", bg: "bg-emerald-100", text: "text-emerald-700", preview: "bg-emerald-500" },
  { name: "Teal", bg: "bg-teal-100", text: "text-teal-700", preview: "bg-teal-500" },
  
  // Нейтральные
  { name: "Slate", bg: "bg-slate-100", text: "text-slate-700", preview: "bg-slate-500" },
  { name: "Gray", bg: "bg-gray-100", text: "text-gray-700", preview: "bg-gray-500" },
  { name: "Zinc", bg: "bg-zinc-100", text: "text-zinc-700", preview: "bg-zinc-500" },
  { name: "Stone", bg: "bg-stone-100", text: "text-stone-700", preview: "bg-stone-500" },
];

export default function CategoryEditor({ open, onClose, category, onSave }) {
  const [formData, setFormData] = useState({
    category_key: "",
    label: "",
    icon: "Package",
    color: "Slate",
    is_hidden: false,
    is_private: false
  });
  const [iconSearch, setIconSearch] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (category) {
      setFormData({
        category_key: category.category_key || "",
        label: category.label || "",
        icon: category.icon || "Package",
        color: category.color || "Slate",
        is_hidden: category.is_hidden || false,
        is_private: category.is_private || false
      });
    } else {
      setFormData({
        category_key: "",
        label: "",
        icon: "Package",
        color: "Slate",
        is_hidden: false,
        is_private: false
      });
    }
    setIconSearch("");
  }, [category, open]);

  const handleSave = async () => {
    if (!formData.category_key.trim() || !formData.label.trim()) return;
    setIsSaving(true);
    await onSave(formData, category?.id);
    setIsSaving(false);
    onClose();
  };

  const filteredIcons = ICONS.filter(i => 
    i.name.toLowerCase().includes(iconSearch.toLowerCase()) ||
    i.group.toLowerCase().includes(iconSearch.toLowerCase())
  );

  // Group icons
  const groupedIcons = filteredIcons.reduce((acc, icon) => {
    if (!acc[icon.group]) acc[icon.group] = [];
    acc[icon.group].push(icon);
    return acc;
  }, {});

  const selectedIcon = ICONS.find(i => i.name === formData.icon);
  const selectedColor = COLORS.find(c => c.name === formData.color);
  const SelectedIconComponent = selectedIcon?.icon || Package;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>
            {category ? "Редактировать категорию" : "Новая категория"}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 py-4">
          {/* Preview */}
          <div className="flex items-center justify-center p-4 bg-slate-50 rounded-xl">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${selectedColor?.bg} ${selectedColor?.text}`}>
              <SelectedIconComponent className="w-5 h-5" />
              <span className="font-medium">{formData.label || "Название"}</span>
            </div>
          </div>

          {/* Category Key */}
          <div className="space-y-2">
            <Label>Ключ категории (category_key)</Label>
            <Input
              placeholder="например: cameras, lighting, audio"
              value={formData.category_key}
              onChange={(e) => setFormData({ ...formData, category_key: e.target.value })}
              className="font-mono"
            />
            <p className="text-xs text-slate-500">
              Используется для связи с оборудованием. Должен совпадать со значением в колонке "cat" таблицы.
            </p>
          </div>

          {/* Label */}
          <div className="space-y-2">
            <Label>Отображаемое название</Label>
            <Input
              placeholder="например: Камеры, Освещение, Звук"
              value={formData.label}
              onChange={(e) => setFormData({ ...formData, label: e.target.value })}
            />
          </div>

          {/* Color Picker */}
          <div className="space-y-2">
            <Label>Цвет</Label>
            <div className="flex flex-wrap gap-2 p-3 bg-slate-50 rounded-lg">
              {COLORS.map((color) => (
                <button
                  key={color.name}
                  type="button"
                  onClick={() => setFormData({ ...formData, color: color.name })}
                  className={`relative w-8 h-8 rounded-full ${color.preview} transition-transform hover:scale-110 ${
                    formData.color === color.name ? "ring-2 ring-offset-2 ring-slate-400 scale-110" : ""
                  }`}
                  title={color.name}
                >
                  {formData.color === color.name && (
                    <Check className="w-4 h-4 text-white absolute inset-0 m-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Icon Picker */}
          <div className="space-y-2">
            <Label>Иконка</Label>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Поиск иконок..."
                value={iconSearch}
                onChange={(e) => setIconSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <ScrollArea className="h-48 border rounded-lg p-3">
              {Object.entries(groupedIcons).map(([group, icons]) => (
                <div key={group} className="mb-3">
                  <p className="text-xs font-medium text-slate-500 mb-2">{group}</p>
                  <div className="flex flex-wrap gap-1">
                    {icons.map(({ name, icon: Icon }) => (
                      <button
                        key={name}
                        type="button"
                        onClick={() => setFormData({ ...formData, icon: name })}
                        className={`p-2 rounded-lg transition-all ${
                          formData.icon === name
                            ? `${selectedColor?.bg} ${selectedColor?.text} ring-2 ring-offset-1 ring-slate-300`
                            : "hover:bg-slate-100 text-slate-600"
                        }`}
                        title={name}
                      >
                        <Icon className="w-5 h-5" />
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              {Object.keys(groupedIcons).length === 0 && (
                <p className="text-center text-slate-500 py-4">Иконки не найдены</p>
              )}
            </ScrollArea>
          </div>

          {/* Privacy Settings */}
          <div className="space-y-4 pt-2 border-t">
            <Label className="text-slate-700">Настройки видимости</Label>
            
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-3">
                <EyeOff className="w-4 h-4 text-slate-500" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Скрытая категория</p>
                  <p className="text-xs text-slate-500">Не отображается в каталоге</p>
                </div>
              </div>
              <Switch
                checked={formData.is_hidden}
                onCheckedChange={(checked) => setFormData({ ...formData, is_hidden: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-3">
                <LockIcon className="w-4 h-4 text-slate-500" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Приватная категория</p>
                  <p className="text-xs text-slate-500">Видна только администраторам</p>
                </div>
              </div>
              <Switch
                checked={formData.is_private}
                onCheckedChange={(checked) => setFormData({ ...formData, is_private: checked })}
              />
            </div>
          </div>
        </div>

        <DialogFooter className="border-t pt-4">
          <Button variant="outline" onClick={onClose}>
            Отмена
          </Button>
          <Button
            onClick={handleSave}
            disabled={!formData.category_key.trim() || !formData.label.trim() || isSaving}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            {isSaving ? "Сохранение..." : "Сохранить"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export { ICONS, COLORS };