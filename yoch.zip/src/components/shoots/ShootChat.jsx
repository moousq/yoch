import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Send, Loader2, MessageCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { toast } from "sonner";

export default function ShootChat({ shootId, isAdmin }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [requiresResponse, setRequiresResponse] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      try {
        const [messagesData, user] = await Promise.all([
          base44.entities.ShootMessage.filter({ shoot: shootId }, "created_date"),
          base44.auth.me()
        ]);
        setMessages(messagesData);
        setCurrentUser(user);
      } catch (e) {
        console.error(e);
      }
      setIsLoading(false);
    };
    load();
  }, [shootId]);

  // Only scroll to bottom when user sends a new message, not on initial load
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSend = async () => {
    if (!newMessage.trim()) return;
    
    setIsSending(true);
    try {
      const messageData = {
        shoot: shootId,
        message: newMessage.trim(),
        author_name: currentUser?.full_name || "Пользователь",
        is_admin: isAdmin,
        requires_response: isAdmin ? requiresResponse : false
      };
      
      const created = await base44.entities.ShootMessage.create(messageData);
      setMessages([...messages, created]);
      setNewMessage("");
      setRequiresResponse(false);
      
      // Create notification for admins when user sends a message
      if (!isAdmin) {
        try {
          // Get all admin users
          const users = await base44.entities.User.list();
          const admins = users.filter(u => u.role === "admin");
          
          // Get shoot info for notification
          const shoots = await base44.entities.Shoot.filter({ id: shootId });
          const shoot = shoots[0];
          
          for (const admin of admins) {
            await base44.entities.Notification.create({
              user_email: admin.email,
              title: "Новое сообщение",
              message: `${currentUser?.full_name || "Пользователь"} написал сообщение в заявке "${shoot?.title || "Заявка"}"`,
              type: "message",
              shoot_id: shootId
            });
          }
        } catch (e) {
          console.error("Failed to create notification:", e);
        }
      }
      
      // Scroll to bottom after sending
      setTimeout(scrollToBottom, 100);
      toast.success("Сообщение отправлено");
    } catch (e) {
      toast.error("Ошибка при отправке");
    }
    setIsSending(false);
  };

  const pendingResponse = messages.some(m => m.is_admin && m.requires_response) && 
    !messages.some(m => !m.is_admin && messages.findIndex(msg => msg.id === m.id) > messages.findLastIndex(msg => msg.is_admin && msg.requires_response));

  return (
    <Card className="border-slate-200/60">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          Переписка
        </CardTitle>
        {pendingResponse && !isAdmin && (
          <Badge className="bg-amber-100 text-amber-700 border-amber-200">
            <AlertCircle className="w-3 h-3 mr-1" />
            Требуется ответ
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
          </div>
        ) : (
          <>
            {/* Messages */}
            <div className="space-y-3 max-h-80 overflow-y-auto mb-4 p-1">
              {messages.length === 0 ? (
                <p className="text-center text-slate-500 py-6">Нет сообщений</p>
              ) : (
                messages.map(msg => (
                  <div
                    key={msg.id}
                    className={`p-3 rounded-lg ${
                      msg.is_admin 
                        ? "bg-indigo-50 border border-indigo-100 ml-4" 
                        : "bg-slate-50 border border-slate-100 mr-4"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className={`text-sm font-medium ${msg.is_admin ? "text-indigo-700" : "text-slate-700"}`}>
                        {msg.author_name || (msg.is_admin ? "Админ" : "Пользователь")}
                        {msg.is_admin && <Badge className="ml-2 text-xs bg-indigo-100 text-indigo-600">Админ</Badge>}
                      </span>
                      <span className="text-xs text-slate-400">
                        {msg.created_date && format(new Date(msg.created_date), "d MMM, HH:mm", { locale: ru })}
                      </span>
                    </div>
                    <p className="text-sm text-slate-700 whitespace-pre-wrap">{msg.message}</p>
                    {msg.requires_response && (
                      <Badge className="mt-2 bg-amber-100 text-amber-700 border-amber-200 text-xs">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Требуется ответ
                      </Badge>
                    )}
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="space-y-3 border-t border-slate-100 pt-4">
              <Textarea
                placeholder="Введите сообщение..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                className="bg-slate-50 min-h-20"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
              />
              
              <div className="flex items-center justify-between">
                {isAdmin && (
                  <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                    <Checkbox
                      checked={requiresResponse}
                      onCheckedChange={setRequiresResponse}
                    />
                    Требуется ответ пользователя
                  </label>
                )}
                {!isAdmin && <div />}
                
                <Button
                  onClick={handleSend}
                  disabled={isSending || !newMessage.trim()}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  {isSending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Отправить
                    </>
                  )}
                </Button>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}