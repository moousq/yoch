import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, CloudOff, Clock, CheckCircle, XCircle } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const statusConfig = {
  pending: { label: "Ожидает", icon: Clock, color: "text-amber-600 border-amber-200 bg-amber-50" },
  approved: { label: "Одобрено", icon: CheckCircle, color: "text-green-600 border-green-200 bg-green-50" },
  rejected: { label: "Отклонено", icon: XCircle, color: "text-red-600 border-red-200 bg-red-50" }
};

export default function ShootCard({ shoot }) {
  const isLocal = shoot._isLocal || shoot.id?.startsWith("temp_");
  const status = shoot.status || "pending";
  const StatusIcon = statusConfig[status]?.icon || Clock;
  
  return (
    <Link to={createPageUrl(`ShootDetail?id=${shoot.id}`)}>
      <Card className="group hover:shadow-lg hover:shadow-slate-200/50 transition-all duration-300 border-slate-200/60 bg-white overflow-hidden">
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-3">
            <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
              {shoot.title}
            </h3>
            <div className="flex gap-2">
              {isLocal && (
                <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50 text-xs">
                  <CloudOff className="w-3 h-3 mr-1" />
                  Local
                </Badge>
              )}
              <Badge variant="outline" className={`${statusConfig[status]?.color} text-xs`}>
                <StatusIcon className="w-3 h-3 mr-1" />
                {statusConfig[status]?.label}
              </Badge>
            </div>
          </div>
          
          {shoot.date && (
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Calendar className="w-4 h-4" />
              <span>{format(new Date(shoot.date), "d MMM yyyy", { locale: ru })}</span>
            </div>
          )}
          
          {shoot.responsible && (
            <div className="text-sm text-slate-500 mt-1">
              {shoot.responsible}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}