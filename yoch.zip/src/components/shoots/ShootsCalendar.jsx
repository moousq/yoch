import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, Clock, CheckCircle, XCircle } from "lucide-react";
import { format, isSameDay, isWithinInterval, eachDayOfInterval } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const statusConfig = {
  pending: { label: "Ожидает", icon: Clock, color: "bg-amber-100 text-amber-700" },
  approved: { label: "Одобрено", icon: CheckCircle, color: "bg-green-100 text-green-700" },
  rejected: { label: "Отклонено", icon: XCircle, color: "bg-red-100 text-red-700" }
};

export default function ShootsCalendar({ shoots }) {
  const [selectedDate, setSelectedDate] = useState(null);

  // Get shoots for selected date (check if date falls within shoot range)
  const shootsOnDate = selectedDate
    ? shoots.filter(s => {
        if (!s.date) return false;
        const start = new Date(s.date);
        const end = s.end_date && s.end_date >= s.date ? new Date(s.end_date) : start;
        if (isSameDay(selectedDate, start) || isSameDay(selectedDate, end)) return true;
        if (end > start) {
          return selectedDate >= start && selectedDate <= end;
        }
        return false;
      })
    : [];

  // Get all dates that have shoots (including date ranges)
  const shootDates = shoots
    .filter(s => s.date)
    .flatMap(s => {
      const start = new Date(s.date);
      const end = s.end_date && s.end_date >= s.date ? new Date(s.end_date) : start;
      if (isSameDay(start, end)) return [start];
      try {
        return eachDayOfInterval({ start, end });
      } catch {
        return [start];
      }
    });

  return (
    <Card className="border-slate-200/60 w-full">
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-base font-semibold text-slate-900 flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-indigo-600" />
          Календарь съёмок
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 pt-0">
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={setSelectedDate}
          locale={ru}
          className="rounded-md w-full [&_table]:w-full [&_td]:w-10 [&_th]:w-10"
          modifiers={{
            hasShoot: shootDates
          }}
          modifiersStyles={{
            hasShoot: {
              backgroundColor: "#e0e7ff",
              color: "#4338ca",
              fontWeight: "600"
            }
          }}
        />

        {/* Shoots for selected date */}
        {selectedDate && (
          <div className="mt-3 border-t border-slate-100 pt-3">
            <h4 className="text-sm font-medium text-slate-700 mb-2">
              {format(selectedDate, "d MMMM yyyy", { locale: ru })}
            </h4>
            {shootsOnDate.length === 0 ? (
              <p className="text-sm text-slate-500">Нет съёмок на эту дату</p>
            ) : (
              <div className="space-y-2">
                {shootsOnDate.map(shoot => {
                  const status = shoot.status || "pending";
                  const StatusIcon = statusConfig[status]?.icon || Clock;
                  return (
                    <Link
                      key={shoot.id}
                      to={createPageUrl(`ShootDetail?id=${shoot.id}`)}
                      className="block p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium text-slate-900 text-sm truncate">
                          {shoot.title}
                        </span>
                        <Badge className={`${statusConfig[status]?.color} text-xs shrink-0`}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusConfig[status]?.label}
                        </Badge>
                      </div>
                      {shoot.responsible && (
                        <p className="text-xs text-slate-500 mt-1">{shoot.responsible}</p>
                      )}
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}