import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";

const initialState = {
  title: "",
  date: "",
  end_date: "",
  location: "",
  responsible: ""
};

export default function ShootForm({ open, onClose, onSubmit, shoot = null }) {
  const [formData, setFormData] = useState(initialState);
  const [saving, setSaving] = useState(false);

  // Update form when dialog opens with shoot data
  useEffect(() => {
    if (open && shoot) {
      setFormData({
        title: shoot.title || "",
        date: shoot.date || "",
        end_date: shoot.end_date || "",
        location: shoot.location || "",
        responsible: shoot.responsible || ""
      });
    } else if (open && !shoot) {
      setFormData(initialState);
    }
  }, [open]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSubmit(formData);
    setSaving(false);
    onClose();
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            {shoot ? "Редактировать заявку" : "Новая заявка"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="title" className="text-slate-700">Название *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange("title", e.target.value)}
              placeholder="Название съёмки"
              className="mt-1.5"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date" className="text-slate-700">Дата начала *</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleChange("date", e.target.value)}
                className="mt-1.5"
                required
              />
            </div>
            <div>
              <Label htmlFor="end_date" className="text-slate-700">Дата окончания</Label>
              <Input
                id="end_date"
                type="date"
                value={formData.end_date || ""}
                onChange={(e) => handleChange("end_date", e.target.value)}
                className="mt-1.5"
                min={formData.date}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="location" className="text-slate-700">Локация</Label>
            <Input
              id="location"
              value={formData.location || ""}
              onChange={(e) => handleChange("location", e.target.value)}
              placeholder="Адрес или место"
              className="mt-1.5"
            />
          </div>

          <div>
            <Label htmlFor="responsible" className="text-slate-700">Ответственный</Label>
            <Input
              id="responsible"
              value={formData.responsible || ""}
              onChange={(e) => handleChange("responsible", e.target.value)}
              placeholder="Имя ответственного"
              className="mt-1.5"
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Отмена
            </Button>
            <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {shoot ? "Сохранить" : "Создать"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}