import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon, Zap, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function QuickRequestForm() {
  const [title, setTitle] = useState("");
  const [dateRange, setDateRange] = useState({ from: undefined, to: undefined });
  const [responsible, setResponsible] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await base44.auth.me();
        if (user?.full_name) {
          setResponsible(user.full_name);
        }
      } catch (e) {}
    };
    loadUser();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast.error("Введите название съёмки");
      return;
    }
    if (!dateRange.from) {
      toast.error("Выберите дату");
      return;
    }

    // Navigate to Equipment page with prefilled data (no shoot created yet)
    const params = new URLSearchParams();
    params.set("title", title.trim());
    params.set("from", format(dateRange.from, "yyyy-MM-dd"));
    if (dateRange.to) {
      params.set("to", format(dateRange.to, "yyyy-MM-dd"));
    }
    if (responsible.trim()) {
      params.set("responsible", responsible.trim());
    }
    
    window.scrollTo(0, 0);
    navigate(createPageUrl(`Equipment?${params.toString()}`));
  };

  return (
    <Card className="border-slate-200/60 bg-gradient-to-br from-indigo-50 to-purple-50">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold text-slate-900 flex items-center gap-2">
          <Zap className="w-4 h-4 text-indigo-600" />
          Быстрая заявка
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Input
            placeholder="Название съёмки"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-white"
          />
          
          <div className="flex flex-col sm:flex-row gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="flex-1 justify-start gap-2 bg-white text-left">
                  <CalendarIcon className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span className="truncate">
                    {dateRange.from ? (
                      dateRange.to && dateRange.to !== dateRange.from ? (
                        `${format(dateRange.from, "d MMM", { locale: ru })} – ${format(dateRange.to, "d MMM", { locale: ru })}`
                      ) : (
                        format(dateRange.from, "d MMM yyyy", { locale: ru })
                      )
                    ) : (
                      "Даты"
                    )}
                  </span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="range"
                  selected={dateRange}
                  onSelect={(range) => setDateRange(range || { from: undefined, to: undefined })}
                  locale={ru}
                  numberOfMonths={1}
                  className="sm:hidden"
                />
                <Calendar
                  mode="range"
                  selected={dateRange}
                  onSelect={(range) => setDateRange(range || { from: undefined, to: undefined })}
                  locale={ru}
                  numberOfMonths={2}
                  className="hidden sm:block"
                />
              </PopoverContent>
            </Popover>
            
            <Input
              placeholder="Ответственный"
              value={responsible}
              onChange={(e) => setResponsible(e.target.value)}
              className="flex-1 bg-white"
            />
          </div>

          <Button 
            type="submit" 
            className="w-full bg-indigo-600 hover:bg-indigo-700"
          >
            Выбрать технику
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}