import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Upload, FileSpreadsheet, Loader2, CheckCircle, AlertCircle } from "lucide-react";

export default function ImportEquipmentCSV({ open, onClose, onImport }) {
  const [file, setFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState(null);
  const fileInputRef = useRef(null);

  const parseCSV = (text) => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];
    
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/["']/g, ''));
    const rows = [];
    
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].match(/("([^"]*)"|[^,]*)/g) || [];
      const row = {};
      
      headers.forEach((header, index) => {
        let value = values[index]?.trim().replace(/^"|"$/g, '') || '';
        
        // Map common column names
        if (header === 'category' || header === 'type' || header === 'cat') {
          row.category = value;
        } else if (header === 'name' || header === 'item' || header === 'equipment') {
          row.name = value;
        } else if (header === 'description' || header === 'desc' || header === 'notes' || header === 'comment') {
          row.description = value;
        } else if (header === 'quantity' || header === 'qty' || header === 'stock' || header === 'count') {
          row.stock = parseInt(value) || 1;
        } else if (header === 'owner' || header === 'владелец') {
          row.owner = value;
        } else if (header === 'condition' || header === 'состояние') {
          row.condition = value;
        } else if (header === 'rent price' || header === 'rent_price') {
          row.rent_price = parseFloat(value.replace(/\s/g, '').replace(',', '.')) || 0;
        } else if (header === 'price' || header === 'цена' || header === 'стоимость') {
          row.price = parseFloat(value.replace(/\s/g, '').replace(',', '.')) || 0;
        } else if (header === 'id' || header === 'sheet_id') {
          row.sheet_id = value;
        }
      });
      
      // Validate required fields
      if (row.name) {
        rows.push(row);
      }
    }
    
    return rows;
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResult(null);
    }
  };

  const handleImport = async () => {
    if (!file) return;
    
    setImporting(true);
    setResult(null);
    
    try {
      const text = await file.text();
      const records = parseCSV(text);
      
      if (records.length === 0) {
        setResult({ success: false, message: "No valid records found in CSV" });
        setImporting(false);
        return;
      }
      
      await onImport(records);
      setResult({ success: true, message: `Imported ${records.length} equipment items` });
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (error) {
      setResult({ success: false, message: error.message || "Import failed" });
    } finally {
      setImporting(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
            Import from CSV
          </DialogTitle>
          <DialogDescription className="text-slate-500">
            Upload a CSV file exported from Google Sheets or Excel
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          <div className="text-sm text-slate-600 bg-slate-50 rounded-lg p-3">
            <p className="font-medium mb-1">Expected columns:</p>
            <ul className="text-xs space-y-0.5 text-slate-500">
              <li>• <strong>name</strong> (required) - Equipment name</li>
              <li>• <strong>category</strong> or <strong>cat</strong> - Category</li>
              <li>• <strong>description</strong> or <strong>comment</strong> - Notes</li>
              <li>• <strong>quantity</strong> or <strong>stock</strong> - In stock</li>
              <li>• <strong>owner</strong> - Owner name</li>
              <li>• <strong>condition</strong> - Item condition</li>
              <li>• <strong>rent price</strong> - Daily rental price</li>
              <li>• <strong>price</strong> - Full equipment price</li>
              <li>• <strong>id</strong> or <strong>sheet_id</strong> - Unique ID</li>
            </ul>
          </div>

          <div 
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-colors ${
              file ? 'border-indigo-300 bg-indigo-50' : 'border-slate-200 hover:border-slate-300'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
            />
            
            {file ? (
              <div className="flex items-center justify-center gap-2 text-indigo-700">
                <FileSpreadsheet className="w-5 h-5" />
                <span className="font-medium">{file.name}</span>
              </div>
            ) : (
              <div className="cursor-pointer">
                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-sm text-slate-600">Click to select CSV file</p>
              </div>
            )}
          </div>

          {result && (
            <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${
              result.success 
                ? 'bg-emerald-50 text-emerald-700' 
                : 'bg-red-50 text-red-700'
            }`}>
              {result.success ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                <AlertCircle className="w-4 h-4" />
              )}
              {result.message}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={handleClose}>
              {result?.success ? 'Done' : 'Cancel'}
            </Button>
            {!result?.success && (
              <Button 
                onClick={handleImport} 
                disabled={!file || importing}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                {importing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Import
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}