import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CloudOff, Trash2, Plus, Minus, Camera, Aperture, Box, Wifi, Zap, Wrench, Package, CircleDot, Sun, HardDrive, Cable, Mic, Target, Layers, Anchor, Grip, Plug, Monitor, Briefcase, Backpack, Contrast, Orbit } from "lucide-react";
import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const getDaysLabel = (days) => {
  const lastDigit = days % 10;
  const lastTwoDigits = days % 100;
  
  if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
    return `${days} суток`;
  }
  if (lastDigit === 1) {
    return `${days} сутки`;
  }
  return `${days} суток`;
};

const ICON_MAP = {
  "Камеры": Camera,
  "Оптика": Aperture,
  "Свет": Zap,
  "Звук": Wifi,
  "Grip": Box,
  "Прочее": Wrench
};

const COLOR_MAP = {
  "Камеры": "bg-blue-100 text-blue-700 border-blue-200",
  "Оптика": "bg-purple-100 text-purple-700 border-purple-200",
  "Свет": "bg-amber-100 text-amber-700 border-amber-200",
  "Звук": "bg-emerald-100 text-emerald-700 border-emerald-200",
  "Grip": "bg-slate-100 text-slate-700 border-slate-200",
  "Прочее": "bg-pink-100 text-pink-700 border-pink-200"
};

export default function ShootEquipmentList({ 
  shootEquipment, 
  equipmentCatalog, 
  shoot, 
  onRemove, 
  onUpdateQuantity,
  getMaxQuantity,
  isAdmin = false
}) {
  const [categorySettings, setCategorySettings] = useState([]);

  useEffect(() => {
    const loadCategorySettings = async () => {
      try {
        const settings = await base44.entities.CategorySettings.list();
        setCategorySettings(settings);
      } catch (e) {
        console.error("Failed to load category settings:", e);
      }
    };
    loadCategorySettings();
  }, []);

  const shootDays = shoot?.date && shoot?.end_date && shoot.end_date !== shoot.date
    ? Math.max(1, Math.ceil((new Date(shoot.end_date) - new Date(shoot.date)) / (1000 * 60 * 60 * 24)) + 1)
    : 1;

  const getCategoryDisplay = (categoryKey) => {
    const setting = categorySettings.find(s => s.category_key === categoryKey);
    if (setting) {
      const iconMap = {
        Camera: Camera,
        Aperture: Aperture,
        Box: Box,
        Wifi: Wifi,
        Zap: Zap,
        Wrench: Wrench,
        Package: Package,
        CircleDot: CircleDot,
        Sun: Sun,
        HardDrive: HardDrive,
        Cable: Cable,
        Mic: Mic,
        Target: Target,
        Layers: Layers,
        Anchor: Anchor,
        Grip: Grip,
        Plug: Plug,
        Monitor: Monitor,
        Briefcase: Briefcase,
        Backpack: Backpack,
        Contrast: Contrast,
        Orbit: Orbit
      };
      const colorMap = {
        Blue: "bg-blue-100 text-blue-700",
        Purple: "bg-purple-100 text-purple-700",
        Violet: "bg-violet-100 text-violet-700",
        Amber: "bg-amber-100 text-amber-700",
        Yellow: "bg-yellow-100 text-yellow-700",
        Green: "bg-green-100 text-green-700",
        Emerald: "bg-emerald-100 text-emerald-700",
        Teal: "bg-teal-100 text-teal-700",
        Cyan: "bg-cyan-100 text-cyan-700",
        Sky: "bg-sky-100 text-sky-700",
        Indigo: "bg-indigo-100 text-indigo-700",
        Fuchsia: "bg-fuchsia-100 text-fuchsia-700",
        Pink: "bg-pink-100 text-pink-700",
        Rose: "bg-rose-100 text-rose-700",
        Red: "bg-red-100 text-red-700",
        Orange: "bg-orange-100 text-orange-700",
        Slate: "bg-slate-100 text-slate-700",
        Gray: "bg-gray-100 text-gray-700",
        Zinc: "bg-zinc-100 text-zinc-700",
        Stone: "bg-stone-100 text-stone-700"
      };
      return {
        label: setting.label,
        icon: iconMap[setting.icon] || Package,
        color: colorMap[setting.color] || "bg-slate-100 text-slate-700"
      };
    }
    const IconComponent = ICON_MAP[categoryKey] || Package;
    return {
      label: categoryKey,
      icon: IconComponent,
      color: COLOR_MAP[categoryKey] || "bg-slate-100 text-slate-700"
    };
  };

  // Group equipment by category
  const groupedEquipment = shootEquipment.reduce((acc, eq) => {
    const catalogItem = equipmentCatalog.find(e => e.id === eq.equipment);
    const category = catalogItem?.category || 'Прочее';
    if (!acc[category]) acc[category] = [];
    acc[category].push(eq);
    return acc;
  }, {});

  const categories = Object.keys(groupedEquipment).sort();

  const total = shootEquipment.reduce((sum, eq) => {
    const days = eq.days || shootDays;
    return sum + ((eq.quantity || 1) * days * (eq.rent_price || 0));
  }, 0);

  return (
    <>
      {/* Desktop Table */}
      <div className="hidden md:block space-y-4">
        {categories.map((categoryKey) => {
          const items = groupedEquipment[categoryKey];
          const categoryDisplay = getCategoryDisplay(categoryKey);
          const CategoryIcon = categoryDisplay?.icon;
          
          return (
            <div key={categoryKey} className="border border-slate-200/60 rounded-xl overflow-hidden">
              {/* Category Header */}
              <div className={`px-4 py-2.5 border-b ${categoryDisplay.color} flex items-center gap-2`}>
                {CategoryIcon && <CategoryIcon className="w-4 h-4" />}
                <h3 className="font-semibold text-sm">{categoryDisplay.label}</h3>
                <span className="text-xs opacity-75">({items.length})</span>
              </div>

              {/* Equipment Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 text-left text-slate-600">
                    <tr>
                      <th className="px-3 py-3 font-medium text-xs w-24">ID</th>
                      <th className="px-3 py-3 font-medium">Название</th>
                      <th className="px-3 py-3 font-medium text-center w-20">Кол-во</th>
                      <th className="px-3 py-3 font-medium text-center w-14">Суток</th>
                      <th className="px-3 py-3 font-medium text-right w-20">₽/сутки</th>
                      <th className="px-3 py-3 font-medium text-right w-20">Итого</th>
                      <th className="px-3 py-3 w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map(eq => {
                      const eqIsLocal = eq._isLocal || eq.id?.startsWith("temp_");
                      const allIds = equipmentCatalog
                        .filter(e => e.name?.toLowerCase().trim() === eq.equipment_name?.toLowerCase().trim())
                        .map(e => e.sheet_id)
                        .filter(Boolean);
                      const days = eq.days || shootDays;
                      const lineTotal = (eq.quantity || 1) * days * (eq.rent_price || 0);
                      
                      return (
                        <tr key={eq.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-3 py-3">
                            <div className="font-mono text-xs text-slate-500">
                              {allIds.length > 0 ? allIds.join(', ') : "—"}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-slate-900">{eq.equipment_name || "Equipment"}</span>
                              {eqIsLocal && <CloudOff className="w-3.5 h-3.5 text-amber-500" />}
                            </div>
                            {eq.comment && <div className="text-xs text-slate-500 truncate max-w-xs">{eq.comment}</div>}
                          </td>
                          <td className="px-3 py-3 text-center">
                            {isAdmin ? (
                              <div className="flex items-center justify-center gap-1">
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => onUpdateQuantity(eq.id, -1)}
                                  disabled={(eq.quantity || 1) <= 1}
                                >
                                  <Minus className="w-3 h-3" />
                                </Button>
                                <span className="w-6 text-center font-medium">{eq.quantity || 1}</span>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => onUpdateQuantity(eq.id, 1)}
                                  disabled={getMaxQuantity && (eq.quantity || 1) >= getMaxQuantity(eq.equipment)}
                                >
                                  <Plus className="w-3 h-3" />
                                </Button>
                              </div>
                            ) : (
                              <span className="font-medium">{eq.quantity || 1}</span>
                            )}
                          </td>
                          <td className="px-3 py-3 text-center font-medium">{days}</td>
                          <td className="px-3 py-3 text-right text-slate-600">
                            {eq.rent_price > 0 ? `${eq.rent_price.toLocaleString()} ₽` : "—"}
                          </td>
                          <td className="px-3 py-3 text-right font-medium text-indigo-600">
                            {lineTotal > 0 ? `${lineTotal.toLocaleString()} ₽` : "—"}
                          </td>
                          <td className="px-3 py-3 text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => onRemove(eq.id)}
                              className="text-red-400 hover:text-red-600 hover:bg-red-50 h-8 w-8"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
        
        {total > 0 && (
          <div className="flex justify-end items-center gap-4 pt-2 px-4">
            <span className="text-slate-700 font-medium">Общая стоимость:</span>
            <span className="text-xl font-bold text-slate-900">{total.toLocaleString()} ₽</span>
          </div>
        )}
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-4">
        {categories.map((categoryKey) => {
          const items = groupedEquipment[categoryKey];
          const categoryDisplay = getCategoryDisplay(categoryKey);
          const CategoryIcon = categoryDisplay?.icon;
          
          return (
            <div key={categoryKey} className="border border-slate-200/60 rounded-xl overflow-hidden">
              {/* Category Header */}
              <div className={`px-4 py-2.5 border-b ${categoryDisplay.color} flex items-center gap-2`}>
                {CategoryIcon && <CategoryIcon className="w-4 h-4" />}
                <h3 className="font-semibold text-sm">{categoryDisplay.label}</h3>
                <span className="text-xs opacity-75">({items.length})</span>
              </div>

              {/* Equipment Cards */}
              <div className="divide-y divide-slate-100">
                {items.map(eq => {
                  const eqIsLocal = eq._isLocal || eq.id?.startsWith("temp_");
                  const allIds = equipmentCatalog
                    .filter(e => e.name?.toLowerCase().trim() === eq.equipment_name?.toLowerCase().trim())
                    .map(e => e.sheet_id)
                    .filter(Boolean);
                  const days = eq.days || shootDays;
                  const lineTotal = (eq.quantity || 1) * days * (eq.rent_price || 0);
                  
                  return (
                    <div key={eq.id} className="p-3 hover:bg-slate-50">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-slate-900 truncate">{eq.equipment_name || "Equipment"}</span>
                            {eqIsLocal && <CloudOff className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                          </div>
                          {allIds.length > 0 && (
                            <p className="font-mono text-xs text-slate-500 mt-0.5">ID: {allIds.join(', ')}</p>
                          )}
                          {eq.comment && (
                            <p className="text-xs text-slate-400 mt-1 truncate">{eq.comment}</p>
                          )}
                        </div>
<Button
  variant="ghost"
  size="icon"
  onClick={() => onRemove(eq.id)}
  className="text-red-500 hover:bg-red-50 hover:text-red-600 h-7 w-7 flex-shrink-0"
>
  <Trash2 className="w-3.5 h-3.5" />
</Button>
                      </div>
                      
                      {isAdmin && (
                        <div className="mt-2">
                          <p className="text-slate-500 text-xs mb-1">Количество</p>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => onUpdateQuantity(eq.id, -1)}
                              disabled={(eq.quantity || 1) <= 1}
                            >
                              <Minus className="w-3 h-3" />
                            </Button>
                            <span className="w-8 text-center font-medium text-xs">{eq.quantity || 1}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => onUpdateQuantity(eq.id, 1)}
                              disabled={getMaxQuantity && (eq.quantity || 1) >= getMaxQuantity(eq.equipment)}
                            >
                              <Plus className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        
        {total > 0 && (
          <div className="bg-indigo-50 rounded-lg p-3 flex justify-between items-center">
            <span className="font-medium text-slate-700 text-sm">Общая стоимость:</span>
            <span className="font-bold text-indigo-600 text-lg">{total.toLocaleString()} ₽</span>
          </div>
        )}
      </div>
    </>
  );
}