import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Download, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

const EXPORT_FIELDS = [
  { key: "checkbox", label: "Чекбокс ✓", default: true },
  { key: "sheet_id", label: "ID (из базы)", default: true },
  { key: "name", label: "Название", default: true },
  { key: "quantity", label: "Количество", default: true },
  { key: "days", label: "Дней аренды", default: true },
  { key: "rent_price", label: "Цена/день", default: true },
  { key: "line_total", label: "Сумма", default: true },
  { key: "category", label: "Категория", default: false },
  { key: "condition", label: "Состояние", default: false },
  { key: "owner", label: "Владелец", default: false },
  { key: "price", label: "Полная стоимость", default: false },
  { key: "comment", label: "Примечание", default: false },
];

export default function ExportFieldsDialog({ open, onClose, onExport, isExporting }) {
  const [selectedFields, setSelectedFields] = useState(
    EXPORT_FIELDS.filter(f => f.default).map(f => f.key)
  );

  useEffect(() => {
    if (open) {
      loadSavedSettings();
    }
  }, [open]);

  const loadSavedSettings = async () => {
    try {
      const user = await base44.auth.me();
      if (user?.shoot_export_fields && Array.isArray(user.shoot_export_fields)) {
        setSelectedFields(user.shoot_export_fields);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleField = (fieldKey) => {
    setSelectedFields(prev => {
      if (prev.includes(fieldKey)) {
        return prev.filter(k => k !== fieldKey);
      }
      return [...prev, fieldKey];
    });
  };

  const handleExport = async () => {
    // Save settings
    try {
      await base44.auth.updateMe({ shoot_export_fields: selectedFields });
    } catch (e) {
      console.error(e);
    }
    onExport(selectedFields);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Настройки экспорта</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 py-4">
          <p className="text-sm text-slate-500 mb-4">
            Выберите поля для включения в экспорт
          </p>
          {EXPORT_FIELDS.map(field => (
            <div
              key={field.key}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                selectedFields.includes(field.key)
                  ? "bg-indigo-50 border-indigo-200"
                  : "bg-white border-slate-200 hover:border-slate-300"
              }`}
              onClick={() => toggleField(field.key)}
            >
              <Checkbox
                id={field.key}
                checked={selectedFields.includes(field.key)}
                onCheckedChange={(checked) => {
                  if (checked !== selectedFields.includes(field.key)) {
                    toggleField(field.key);
                  }
                }}
                onClick={(e) => e.stopPropagation()}
              />
              <Label htmlFor={field.key} className="flex-1 cursor-pointer">
                {field.label}
              </Label>
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Отмена
          </Button>
          <Button
            onClick={handleExport}
            disabled={isExporting || selectedFields.length === 0}
            className="bg-indigo-600 hover:bg-indigo-700 gap-2"
          >
            {isExporting && <Loader2 className="w-4 h-4 animate-spin" />}
            <Download className="w-4 h-4" />
            Экспорт
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}