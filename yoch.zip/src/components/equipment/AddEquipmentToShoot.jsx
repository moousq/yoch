import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Search, Plus, Minus, Package, Camera, Aperture, Box, Wifi, Zap, Wrench, CircleDot, Sun, HardDrive, Cable, Mic, Target, Layers, Anchor, Grip, Plug, Monitor, Briefcase, Backpack, Contrast, Orbit } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";

const ICON_MAP = {
  Camera: Camera,
  Aperture: Aperture,
  Box: Box,
  Wifi: Wifi,
  Zap: Zap,
  Wrench: Wrench,
  Package: Package,
  CircleDot: CircleDot,
  Sun: Sun,
  HardDrive: HardDrive,
  Cable: Cable,
  Mic: Mic,
  Target: Target,
  Layers: Layers,
  Anchor: Anchor,
  Grip: Grip,
  Plug: Plug,
  Monitor: Monitor,
  Briefcase: Briefcase,
  Backpack: Backpack,
  Contrast: Contrast,
  Orbit: Orbit
};

const COLOR_MAP = {
  Blue: "bg-blue-100 text-blue-700",
  Purple: "bg-purple-100 text-purple-700",
  Violet: "bg-violet-100 text-violet-700",
  Amber: "bg-amber-100 text-amber-700",
  Yellow: "bg-yellow-100 text-yellow-700",
  Green: "bg-green-100 text-green-700",
  Emerald: "bg-emerald-100 text-emerald-700",
  Teal: "bg-teal-100 text-teal-700",
  Cyan: "bg-cyan-100 text-cyan-700",
  Sky: "bg-sky-100 text-sky-700",
  Indigo: "bg-indigo-100 text-indigo-700",
  Fuchsia: "bg-fuchsia-100 text-fuchsia-700",
  Pink: "bg-pink-100 text-pink-700",
  Rose: "bg-rose-100 text-rose-700",
  Red: "bg-red-100 text-red-700",
  Orange: "bg-orange-100 text-orange-700",
  Slate: "bg-slate-100 text-slate-700",
  Gray: "bg-gray-100 text-gray-700",
  Zinc: "bg-zinc-100 text-zinc-700",
  Stone: "bg-stone-100 text-stone-700"
};

export default function AddEquipmentToShoot({ 
  open, 
  onClose, 
  onSubmit, 
  equipmentCatalog,
  shootEquipment = [],
  isLoadingCatalog,
  shootDays = 1 // Number of days from shoot date range
}) {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [quantities, setQuantities] = useState({});
  const [categorySettings, setCategorySettings] = useState({});
  const [saving, setSaving] = useState(false);

  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const settings = await base44.entities.CategorySettings.list();
        const settingsMap = {};
        settings.forEach(s => {
          settingsMap[s.category_key] = s;
        });
        setCategorySettings(settingsMap);
        
        // Check if user is admin
        const user = await base44.auth.me();
        setIsAdmin(user?.role === "admin");
      } catch (e) {
        console.error("Failed to load category settings:", e);
      }
    };
    if (open) {
      loadSettings();
    }
  }, [open]);

  const getCategoryDisplay = (category) => {
    const setting = categorySettings[category];
    if (setting) {
      return {
        color: COLOR_MAP[setting.color] || "bg-slate-100 text-slate-600",
        label: setting.label || category,
        icon: ICON_MAP[setting.icon] || Package
      };
    }
    return { 
      color: "bg-slate-100 text-slate-600", 
      label: category || "Другое",
      icon: Package
    };
  };

  // Get unique categories
  const categories = [...new Set(equipmentCatalog?.map(e => e.category).filter(Boolean) || [])];

  // Group equipment by name but keep track of all IDs
  const groupedEquipment = (equipmentCatalog || []).reduce((acc, eq) => {
    const key = eq.name?.toLowerCase().trim();
    if (!key) return acc;
    if (!acc[key]) {
      acc[key] = {
        ...eq,
        ids: [eq.id],
        stock: eq.stock || 1,
        alreadyInShoot: 0
      };
    } else {
      acc[key].ids.push(eq.id);
      acc[key].stock += (eq.stock || 1);
    }
    return acc;
  }, {});

  // Calculate already added quantities across all IDs with same name
  (shootEquipment || []).forEach(se => {
    const key = se.equipment_name?.toLowerCase().trim();
    if (key && groupedEquipment[key]) {
      groupedEquipment[key].alreadyInShoot += (se.quantity || 1);
    }
  });

  const filteredEquipment = Object.values(groupedEquipment).filter(eq => {
    const matchesSearch = eq.name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || eq.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getQuantity = (id) => quantities[id] || 0;

  const updateQuantity = (item, delta) => {
    const current = getQuantity(item.id);
    const availableToAdd = (item.stock || 1) - (item.alreadyInShoot || 0);
    const newQty = Math.max(0, Math.min(availableToAdd, current + delta));
    setQuantities(prev => ({ ...prev, [item.id]: newQty }));
  };

  const totalSelected = Object.values(quantities).reduce((sum, q) => sum + q, 0);

  const handleSubmit = async () => {
    setSaving(true);
    const selectedItems = Object.entries(quantities).filter(([_, qty]) => qty > 0);
    
    for (const [id, qty] of selectedItems) {
      const item = Object.values(groupedEquipment).find(eq => eq.id === id);
      if (item && item.ids && item.ids.length > 0) {
        // Distribute quantity across available IDs
        let remainingQty = qty;
        for (const equipId of item.ids) {
          if (remainingQty <= 0) break;
          
          const catalogItem = equipmentCatalog.find(e => e.id === equipId);
          const qtyForThisId = Math.min(remainingQty, catalogItem?.stock || 1);
          
          await onSubmit({
            equipment: equipId,
            equipment_name: item.name,
            quantity: qtyForThisId,
            rent_price: item.rent_price || 0,
            days: shootDays
          });
          
          remainingQty -= qtyForThisId;
        }
      }
    }
    
    setSaving(false);
    setQuantities({});
    setSearchTerm("");
    setCategoryFilter("all");
    onClose();
  };

  const handleClose = () => {
    setQuantities({});
    setSearchTerm("");
    setCategoryFilter("all");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-3xl h-[100dvh] sm:h-auto sm:max-h-[85vh] flex flex-col p-0 mx-0 sm:mx-auto rounded-none sm:rounded-lg w-full max-w-full sm:max-w-3xl bg-white">
        <DialogHeader className="px-4 sm:px-6 pt-4 sm:pt-6 pb-3 sm:pb-4">
          <DialogTitle className="text-lg sm:text-xl font-semibold text-slate-900">
            Добавить оборудование
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden flex flex-col px-4 sm:px-6 min-h-0">
          {/* Search first on mobile */}
          <div className="relative mb-3 flex-shrink-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Поиск оборудования..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-white border-slate-200"
            />
          </div>

          {/* Category Tiles - horizontal scroll on mobile */}
          <div className="flex gap-2 mb-3 overflow-x-auto pb-2 -mx-4 px-4 sm:mx-0 sm:px-0 sm:flex-wrap flex-shrink-0">
            <button
              onClick={() => setCategoryFilter("all")}
              className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                categoryFilter === "all"
                  ? "bg-indigo-600 text-white"
                  : "bg-white text-slate-600 border border-slate-200 hover:border-indigo-300"
              }`}
            >
              Все
            </button>
            {categories
              .filter(cat => {
                const setting = categorySettings[cat];
                // Показываем категорию, если нет настроек, или она не приватная, или пользователь - админ
                return !setting || !setting.is_private || isAdmin;
              })
              .map(cat => {
              const catDisplay = getCategoryDisplay(cat);
              const isActive = categoryFilter === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                    isActive
                      ? `${catDisplay.color}`
                      : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300"
                  }`}
                >
                  {catDisplay.label}
                </button>
              );
            })}
          </div>
          
          {/* Table */}
          <div className="flex-1 overflow-y-auto -mx-4 sm:-mx-6">
            {isLoadingCatalog ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
              </div>
            ) : filteredEquipment.length === 0 ? (
              <div className="text-center py-12">
                <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-slate-500">Ничего не найдено</p>
              </div>
            ) : (
              <>
                {/* Mobile Cards */}
                <div className="sm:hidden space-y-2 px-4">
                  {filteredEquipment.map(eq => {
                    const qty = getQuantity(eq.id);
                    const catDisplay = getCategoryDisplay(eq.category);
                    const available = eq.stock - (eq.alreadyInShoot || 0) - qty;
                    
                    return (
                      <div key={eq.id} className="bg-white border border-slate-200 rounded-xl p-3">
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-slate-900 text-sm">{eq.name}</div>
                            <Badge className={`${catDisplay.color} text-xs mt-1`}>
                              {catDisplay.label}
                            </Badge>
                          </div>
                          <div className="flex flex-col items-center flex-shrink-0">
                            <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full font-medium text-sm ${available > 0 ? "bg-indigo-50 text-indigo-700" : "bg-red-50 text-red-600"}`}>
                              {available}
                            </span>
                            <span className="text-xs text-slate-400">шт</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          {eq.rent_price > 0 && (
                            <span className="text-sm text-indigo-600 font-medium">{eq.rent_price.toLocaleString()} ₽/сутки</span>
                          )}
                          {!eq.rent_price && <span />}
                          
                          {qty > 0 ? (
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-9 w-9"
                                onClick={() => updateQuantity(eq, -1)}
                              >
                                <Minus className="w-4 h-4" />
                              </Button>
                              <span className="w-8 text-center font-semibold text-lg">{qty}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-9 w-9"
                                onClick={() => updateQuantity(eq, 1)}
                                disabled={qty >= eq.stock}
                              >
                                <Plus className="w-4 h-4" />
                              </Button>
                            </div>
                          ) : (
                            <Button
                              onClick={() => updateQuantity(eq, 1)}
                              disabled={available <= 0}
                              size="sm"
                              className="bg-indigo-600 hover:bg-indigo-700"
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              Добавить
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Desktop Table */}
                <table className="w-full min-w-[600px] hidden sm:table">
                  <thead className="bg-slate-50 text-left text-sm text-slate-600 sticky top-0">
                    <tr>
                      <th className="px-6 py-3 font-medium min-w-[200px]">Название</th>
                      <th className="px-4 py-3 font-medium min-w-[120px]">Категория</th>
                      <th className="px-4 py-3 font-medium text-right hidden md:table-cell min-w-[100px]">Цена/сутки</th>
                      <th className="px-4 py-3 font-medium text-center min-w-[80px]">В наличии</th>
                      <th className="px-4 py-3 font-medium text-center min-w-[140px]">Количество</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredEquipment.map(eq => {
                      const qty = getQuantity(eq.id);
                      const catDisplay = getCategoryDisplay(eq.category);
                      const available = eq.stock - (eq.alreadyInShoot || 0) - qty;
                      
                      return (
                        <tr key={eq.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-3">
                            <div className="font-medium text-slate-900">{eq.name}</div>
                            {eq.description && (
                              <div className="text-sm text-slate-500 truncate max-w-xs">{eq.description}</div>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <Badge className={catDisplay.color}>
                              {catDisplay.label}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-right hidden md:table-cell">
                            {eq.rent_price > 0 ? (
                              <span className="text-indigo-600 font-medium">{eq.rent_price.toLocaleString()} ₽</span>
                            ) : (
                              <span className="text-slate-400">—</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full font-medium text-sm ${available > 0 ? "bg-indigo-50 text-indigo-700" : "bg-red-50 text-red-600"}`}>
                              {available}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-center gap-1">
                              {qty > 0 ? (
                                <>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => updateQuantity(eq, -1)}
                                  >
                                    <Minus className="w-3 h-3" />
                                  </Button>
                                  <span className="w-8 text-center font-medium">{qty}</span>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => updateQuantity(eq, 1)}
                                    disabled={qty >= eq.stock}
                                  >
                                    <Plus className="w-3 h-3" />
                                  </Button>
                                </>
                              ) : (
                               <Button
                                 variant="outline"
                                 size="sm"
                                 onClick={() => updateQuantity(eq, 1)}
                                 disabled={available <= 0}
                                 className="text-indigo-600 border-indigo-200 hover:bg-indigo-50"
                               >
                                 <Plus className="w-4 h-4 mr-1" />
                                 Добавить
                               </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-2 sm:gap-3 px-4 sm:px-6 py-3 sm:py-4 border-t bg-slate-50">
          <div className="text-sm text-slate-600 text-center sm:text-left">
            {totalSelected > 0 && (
              <span>Выбрано: <strong>{totalSelected}</strong> ед.</span>
            )}
          </div>
          <div className="flex gap-2 sm:gap-3">
            <Button variant="outline" onClick={handleClose} className="flex-1 sm:flex-none">
              Отмена
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={saving || totalSelected === 0}
              className="flex-1 sm:flex-none bg-indigo-600 hover:bg-indigo-700"
            >
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Добавить ({totalSelected})
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}