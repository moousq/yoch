import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";

const initialState = {
  name: "",
  category: "camera",
  description: ""
};

export default function EquipmentForm({ open, onClose, onSubmit, equipment = null }) {
  const [formData, setFormData] = useState(equipment || initialState);
  const [saving, setSaving] = useState(false);

  // Reset form when equipment changes or dialog opens
  useEffect(() => {
    if (open) {
      setFormData(equipment || initialState);
    }
  }, [open, equipment]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSubmit(formData);
    setSaving(false);
    if (!equipment) setFormData(initialState);
    onClose();
  };

  const handleClose = () => {
    if (!equipment) setFormData(initialState);
    onClose();
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            {equipment ? "Edit Equipment" : "Add Equipment"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          <div>
            <Label htmlFor="name" className="text-slate-700">Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="e.g., Sony A7S III"
              className="mt-1.5"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="category" className="text-slate-700">Category *</Label>
            <Select value={formData.category} onValueChange={(v) => handleChange("category", v)}>
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="camera">Camera</SelectItem>
                <SelectItem value="lens">Lens</SelectItem>
                <SelectItem value="lighting">Lighting</SelectItem>
                <SelectItem value="audio">Audio</SelectItem>
                <SelectItem value="grip">Grip</SelectItem>
                <SelectItem value="accessories">Accessories</SelectItem>
                <SelectItem value="props">Props</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="description" className="text-slate-700">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Equipment details..."
              className="mt-1.5 min-h-[80px]"
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {equipment ? "Save Changes" : "Add Equipment"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}