import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Loader2, EyeOff } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function EditEquipmentDialog({ equipment, open, onClose, onSaved }) {
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    description: "",
    condition: "",
    stock: 1,
    owner: "",
    is_hidden: false,
    rent_price: 0,
    price: 0
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (equipment) {
      setFormData({
        name: equipment.name || "",
        category: equipment.category || "",
        description: equipment.description || "",
        condition: equipment.condition || "",
        stock: equipment.stock || 1,
        owner: equipment.owner || "",
        is_hidden: equipment.is_hidden || false,
        rent_price: equipment.rent_price || 0,
        price: equipment.price || 0
      });
    }
  }, [equipment]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await base44.entities.EquipmentCatalog.update(equipment.id, formData);
      toast.success("Оборудование обновлено");
      onSaved?.();
      onClose();
    } catch (e) {
      toast.error("Ошибка при сохранении");
    }
    setIsSaving(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Редактировать оборудование</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          <div>
            <Label>Название</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          
          <div>
            <Label>Категория</Label>
            <Input
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            />
          </div>
          
          <div>
            <Label>Описание</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>
          
          <div>
            <Label>Состояние</Label>
            <Input
              value={formData.condition}
              onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>В наличии</Label>
              <Input
                type="number"
                min="0"
                value={formData.stock}
                onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>₽/день</Label>
              <Input
                type="number"
                min="0"
                value={formData.rent_price}
                onChange={(e) => setFormData({ ...formData, rent_price: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Стоимость</Label>
              <Input
                type="number"
                min="0"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
              />
            </div>
          </div>
          
          <div>
            <Label>Владелец</Label>
            <Input
              value={formData.owner}
              onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div className="flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-slate-500" />
              <div>
                <p className="text-sm font-medium text-slate-700">Скрыть из каталога</p>
                <p className="text-xs text-slate-500">Позиция не будет отображаться</p>
              </div>
            </div>
            <Switch
              checked={formData.is_hidden}
              onCheckedChange={(checked) => setFormData({ ...formData, is_hidden: checked })}
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onClose}>
              Отмена
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Сохранить
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}