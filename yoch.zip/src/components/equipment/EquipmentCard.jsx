import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, Lightbulb, Mic, Box, Package, Aperture, Wrench, CloudOff } from "lucide-react";

const categoryIcons = {
  camera: Camera,
  lens: Aperture,
  lighting: Lightbulb,
  audio: Mic,
  grip: Wrench,
  accessories: Package,
  props: Box
};

const categoryColors = {
  camera: "bg-blue-50 text-blue-700 border-blue-200",
  lens: "bg-violet-50 text-violet-700 border-violet-200",
  lighting: "bg-amber-50 text-amber-700 border-amber-200",
  audio: "bg-emerald-50 text-emerald-700 border-emerald-200",
  grip: "bg-slate-100 text-slate-700 border-slate-200",
  accessories: "bg-pink-50 text-pink-700 border-pink-200",
  props: "bg-cyan-50 text-cyan-700 border-cyan-200"
};

export default function EquipmentCard({ equipment, onSelect, selectable = false, onEdit }) {
  const Icon = categoryIcons[equipment.category] || Box;
  const isLocal = equipment._isLocal || equipment.id?.startsWith("temp_");
  
  const handleClick = () => {
    if (selectable) {
      onSelect?.(equipment);
    } else if (onEdit) {
      onEdit(equipment);
    }
  };
  
  return (
    <Card 
      className={`group overflow-hidden border-slate-200/60 bg-white transition-all duration-300 cursor-pointer hover:shadow-lg hover:shadow-slate-200/50 hover:border-indigo-300`}
      onClick={handleClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${categoryColors[equipment.category]?.split(" ")[0] || "bg-slate-100"}`}>
              <Icon className="w-4 h-4" />
            </div>
            <h3 className="font-semibold text-slate-900 leading-tight">
              {equipment.name}
            </h3>
          </div>
          {isLocal && (
            <CloudOff className="w-4 h-4 text-amber-500 shrink-0" />
          )}
        </div>
        
        <Badge className={`${categoryColors[equipment.category]} border text-xs capitalize mb-2`}>
          {equipment.category}
        </Badge>
        
        {equipment.description && (
          <p className="text-sm text-slate-500 line-clamp-2 mt-2">
            {equipment.description}
          </p>
        )}
      </CardContent>
    </Card>
  );
}