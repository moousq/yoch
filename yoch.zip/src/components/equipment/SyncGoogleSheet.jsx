import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { FileSpreadsheet, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function SyncGoogleSheet({ open, onClose, onSynced, defaultSheetUrl = "" }) {
  const [sheetInput, setSheetInput] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [result, setResult] = useState(null);
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState("");

  // Set default when dialog opens
  useEffect(() => {
    if (open && defaultSheetUrl && !sheetInput) {
      setSheetInput(defaultSheetUrl);
    }
    if (!open) {
      setProgress(0);
      setProgressText("");
    }
  }, [defaultSheetUrl, open]);

  // Extract sheet ID from URL or use as-is
  const extractSheetId = (input) => {
    const match = input.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : input.trim();
  };

  const handleSync = async (mode = 'full') => {
    const sheetId = extractSheetId(sheetInput);
    
    if (!sheetId) {
      setResult({ success: false, message: "Please enter a valid Sheet ID or URL" });
      return;
    }

    setSyncing(true);
    setResult(null);
    setProgress(10);
    setProgressText("Подключение к Google Sheets...");

    try {
      // Simulate progress during the long request
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev < 85) return prev + 5;
          return prev;
        });
      }, 2000);
      
      setProgressText("Загрузка данных из таблицы...");
      
      const response = await base44.functions.invoke('syncGoogleSheet', { sheetId, mode });
      
      clearInterval(progressInterval);
      setProgress(100);
      setProgressText("Готово!");
      
      if (response.data.error) {
        setResult({ success: false, message: response.data.error });
      } else {
        const errMsg = response.data.errors > 0 ? `, ${response.data.errors} ошибок` : '';
        setResult({ 
          success: true, 
          message: mode === 'new_only' 
            ? `Добавлено ${response.data.created} новых позиций${errMsg}`
            : `Синхронизировано ${response.data.total} позиций (${response.data.created} новых, ${response.data.updated} обновлено${errMsg})` 
        });
        onSynced?.();
      }
    } catch (error) {
      setResult({ success: false, message: error.message || "Ошибка синхронизации" });
    } finally {
      setSyncing(false);
    }
  };

  const handleClose = () => {
    setResult(null);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg sm:text-xl font-semibold text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-green-600" />
            Sync from Google Sheets
          </DialogTitle>
          <DialogDescription className="text-slate-500 text-sm">
            Import equipment from your company's Google Sheet
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-sm text-slate-600 bg-slate-50 rounded-lg p-3">
            <p className="font-medium mb-2 text-xs sm:text-sm">Expected columns:</p>
            <ul className="text-xs space-y-1 text-slate-500">
              <li className="break-words">• <strong>ID</strong> (required) - Unique identifier</li>
              <li className="break-words">• <strong>name</strong> (required) - Equipment name</li>
              <li className="break-words">• <strong>cat</strong> / <strong>category</strong> - Category</li>
              <li className="break-words">• <strong>quantity</strong> - Stock</li>
              <li className="break-words">• <strong>condition</strong> - Condition</li>
              <li className="break-words">• <strong>owner</strong> - Owner</li>
              <li className="break-words">• <strong>comment</strong> - Notes</li>
            </ul>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sheetUrl" className="text-sm">Google Sheet URL or ID</Label>
            <Input
              id="sheetUrl"
              placeholder="Paste sheet URL or ID..."
              value={sheetInput}
              onChange={(e) => setSheetInput(e.target.value)}
              className="text-sm"
            />
            <p className="text-xs text-slate-400 break-all">
              Example: https://docs.google.com/spreadsheets/d/abc123.../edit
            </p>
          </div>

          {syncing && (
            <div className="space-y-2">
              <Progress value={progress} className="h-2" />
              <p className="text-xs sm:text-sm text-slate-500 text-center break-words">{progressText}</p>
            </div>
          )}

          {result && (
            <div className={`flex items-start gap-2 p-3 rounded-lg text-xs sm:text-sm ${
              result.success 
                ? 'bg-emerald-50 text-emerald-700' 
                : 'bg-red-50 text-red-700'
            }`}>
              {result.success ? (
                <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              )}
              <span className="break-words">{result.message}</span>
            </div>
          )}

          <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={handleClose} className="w-full sm:w-auto text-sm">
              {result?.success ? 'Готово' : 'Отмена'}
            </Button>
            {!result?.success && (
              <>
                <Button 
                  onClick={() => handleSync('new_only')} 
                  disabled={!sheetInput.trim() || syncing}
                  variant="outline"
                  className="w-full sm:w-auto border-green-300 text-green-700 hover:bg-green-50 text-sm"
                >
                  {syncing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Только новые
                </Button>
                <Button 
                  onClick={() => handleSync('full')} 
                  disabled={!sheetInput.trim() || syncing}
                  className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-sm"
                >
                  {syncing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Полная синхронизация
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}