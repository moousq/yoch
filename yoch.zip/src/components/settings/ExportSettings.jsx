import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Download, Loader2, FileText, GripVertical } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const ALL_FIELDS = [
  { key: "name", label: "Название", default: true },
  { key: "category", label: "Категория", default: true },
  { key: "description", label: "Описание", default: false },
  { key: "condition", label: "Состояние", default: false },
  { key: "stock", label: "Количество", default: true },
  { key: "owner", label: "Владелец", default: false },
  { key: "sheet_id", label: "ID из таблицы", default: false },
  { key: "created_date", label: "Дата создания", default: false },
  { key: "updated_date", label: "Дата обновления", default: false },
];

export default function ExportSettings() {
  const [selectedFields, setSelectedFields] = useState(
    ALL_FIELDS.filter(f => f.default).map(f => f.key)
  );
  const [isExporting, setIsExporting] = useState(false);
  const [equipment, setEquipment] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadEquipment();
    loadSavedSettings();
  }, []);

  const loadEquipment = async () => {
    try {
      const data = await base44.entities.EquipmentCatalog.list();
      setEquipment(data);
    } catch (e) {
      console.error(e);
    }
    setIsLoading(false);
  };

  const loadSavedSettings = async () => {
    try {
      const user = await base44.auth.me();
      if (user?.export_fields && Array.isArray(user.export_fields)) {
        setSelectedFields(user.export_fields);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleField = (fieldKey) => {
    setSelectedFields(prev => {
      if (prev.includes(fieldKey)) {
        return prev.filter(k => k !== fieldKey);
      }
      return [...prev, fieldKey];
    });
  };

  const saveSettings = async () => {
    try {
      await base44.auth.updateMe({ export_fields: selectedFields });
      toast.success("Настройки сохранены");
    } catch (e) {
      toast.error("Ошибка сохранения");
    }
  };

  const exportCSV = () => {
    if (selectedFields.length === 0) {
      toast.error("Выберите хотя бы одно поле");
      return;
    }

    setIsExporting(true);

    try {
      // Build CSV
      const headers = selectedFields.map(key => {
        const field = ALL_FIELDS.find(f => f.key === key);
        return field?.label || key;
      });

      const rows = equipment.map(item => {
        return selectedFields.map(key => {
          let value = item[key];
          if (value === null || value === undefined) return "";
          if (typeof value === "string" && (value.includes(",") || value.includes('"') || value.includes("\n"))) {
            value = `"${value.replace(/"/g, '""')}"`;
          }
          return value;
        }).join(",");
      });

      const csv = [headers.join(","), ...rows].join("\n");
      const BOM = "\uFEFF";
      const blob = new Blob([BOM + csv], { type: "text/csv;charset=utf-8" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `equipment-export-${new Date().toISOString().split("T")[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      toast.success("Файл скачан");
    } catch (e) {
      toast.error("Ошибка экспорта");
    }

    setIsExporting(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            Поля для экспорта
          </CardTitle>
          <CardDescription>
            Выберите поля, которые будут включены в экспорт
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ALL_FIELDS.map(field => (
              <div
                key={field.key}
                className={`flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                  selectedFields.includes(field.key)
                    ? "bg-indigo-50 border-indigo-200"
                    : "bg-white border-slate-200 hover:border-slate-300"
                }`}
                onClick={() => toggleField(field.key)}
              >
                <Checkbox
                  id={field.key}
                  checked={selectedFields.includes(field.key)}
                  onCheckedChange={() => toggleField(field.key)}
                />
                <Label htmlFor={field.key} className="flex-1 cursor-pointer">
                  {field.label}
                </Label>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-6 pt-6 border-t">
            <Button
              variant="outline"
              onClick={saveSettings}
              className="gap-2"
            >
              Сохранить настройки
            </Button>
            <Button
              onClick={exportCSV}
              disabled={isExporting || selectedFields.length === 0}
              className="bg-indigo-600 hover:bg-indigo-700 gap-2"
            >
              {isExporting && <Loader2 className="w-4 h-4 animate-spin" />}
              <Download className="w-4 h-4" />
              Экспортировать CSV ({equipment.length} шт.)
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Preview */}
      {selectedFields.length > 0 && equipment.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm text-slate-600">Превью (первые 3 записи)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    {selectedFields.map(key => {
                      const field = ALL_FIELDS.find(f => f.key === key);
                      return (
                        <th key={key} className="text-left py-2 px-3 font-medium text-slate-600">
                          {field?.label || key}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {equipment.slice(0, 3).map((item, idx) => (
                    <tr key={idx} className="border-b last:border-0">
                      {selectedFields.map(key => (
                        <td key={key} className="py-2 px-3 text-slate-700 truncate max-w-48">
                          {item[key] ?? "-"}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}