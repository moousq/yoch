import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Bell, CheckCircle, XCircle, MessageSquare, Info, Check } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const typeConfig = {
  status_change: { icon: CheckCircle, color: "text-green-600" },
  assignment: { icon: Info, color: "text-blue-600" },
  message: { icon: MessageSquare, color: "text-purple-600" },
  info: { icon: Info, color: "text-slate-600" }
};

export default function NotificationBell() {
  const [notifications, setNotifications] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        
        if (user?.email) {
          const notifs = await base44.entities.Notification.filter(
            { user_email: user.email },
            "-created_date",
            20
          );
          setNotifications(notifs);
        }
      } catch (e) {
        console.error(e);
      }
    };
    load();
    
    // Refresh every 30 seconds
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const markAsRead = async (id) => {
    await base44.entities.Notification.update(id, { is_read: true });
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, is_read: true } : n)
    );
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.is_read);
    await Promise.all(unread.map(n => 
      base44.entities.Notification.update(n.id, { is_read: true })
    ));
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0 shadow-xl border-slate-200" align="end">
        <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600">
          <h3 className="font-semibold text-white">Уведомления</h3>
          {unreadCount > 0 && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={markAllAsRead}
              className="text-xs text-white/90 hover:text-white hover:bg-white/20 h-auto py-1"
            >
              <Check className="w-3 h-3 mr-1" />
              Прочитать все
            </Button>
          )}
        </div>
        
        <div className="max-h-[400px] overflow-auto">
          {notifications.length === 0 ? (
            <div className="p-8 text-center">
              <Bell className="w-10 h-10 text-slate-200 mx-auto mb-2" />
              <p className="text-slate-500">Нет уведомлений</p>
            </div>
          ) : (
            <div>
              {notifications.slice(0, 10).map((notif, index) => {
                const TypeIcon = typeConfig[notif.type]?.icon || Info;
                const iconColor = typeConfig[notif.type]?.color || "text-slate-600";
                const iconBg = {
                  status_change: "bg-green-100",
                  assignment: "bg-blue-100",
                  message: "bg-purple-100",
                  info: "bg-slate-100"
                }[notif.type] || "bg-slate-100";
                
                return (
                  <Link 
                    key={notif.id}
                    to={notif.shoot_id ? createPageUrl(`ShootDetail?id=${notif.shoot_id}`) : "#"}
                    onClick={() => {
                      if (!notif.is_read) markAsRead(notif.id);
                      setIsOpen(false);
                    }}
                    className={`block px-4 py-3 hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-b-0 ${!notif.is_read ? "bg-indigo-50/50" : ""}`}
                  >
                    <div className="flex gap-3">
                      <div className={`w-9 h-9 rounded-full ${iconBg} flex items-center justify-center shrink-0`}>
                        <TypeIcon className={`w-4 h-4 ${iconColor}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className={`text-sm ${!notif.is_read ? "font-semibold text-slate-900" : "font-medium text-slate-700"}`}>
                            {notif.title}
                          </p>
                          {!notif.is_read && (
                            <div className="w-2 h-2 bg-indigo-600 rounded-full shrink-0 mt-1.5" />
                          )}
                        </div>
                        <p className="text-sm text-slate-500 line-clamp-2 mt-0.5">{notif.message}</p>
                        <p className="text-xs text-slate-400 mt-1.5">
                          {format(new Date(notif.created_date), "d MMM, HH:mm", { locale: ru })}
                        </p>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
        
        {notifications.length > 0 && (
          <div className="p-3 border-t bg-slate-50">
            <Link to={createPageUrl("Notifications")} onClick={() => setIsOpen(false)}>
              <Button variant="outline" className="w-full text-sm">
                Показать все уведомления
              </Button>
            </Link>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}