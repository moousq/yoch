import { useSync } from "./SyncManager";
import { Wifi, WifiOff, RefreshCw, CloudOff, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export default function SyncStatusBar() {
  const { isOnline, isSyncing, lastSyncTime, pendingCount, syncWithServer } = useSync();

  return (
    <div className={`
      flex items-center justify-between px-4 py-2 text-sm
      ${isOnline ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}
    `}>
      <div className="flex items-center gap-3">
        {isOnline ? (
          <Wifi className="w-4 h-4" />
        ) : (
          <WifiOff className="w-4 h-4" />
        )}
        <span className="font-medium">
          {isOnline ? "Online" : "Offline"}
        </span>
        
        {pendingCount > 0 && (
          <span className="flex items-center gap-1.5 text-amber-600">
            <CloudOff className="w-3.5 h-3.5" />
            {pendingCount} pending
          </span>
        )}
        
        {lastSyncTime && pendingCount === 0 && isOnline && (
          <span className="flex items-center gap-1.5 text-slate-500">
            <Check className="w-3.5 h-3.5" />
            Synced {format(new Date(lastSyncTime), "h:mm a")}
          </span>
        )}
      </div>
      
      {isOnline && (
        <Button 
          variant="ghost" 
          size="sm"
          onClick={syncWithServer}
          disabled={isSyncing}
          className="h-7 px-2"
        >
          <RefreshCw className={`w-4 h-4 ${isSyncing ? "animate-spin" : ""}`} />
        </Button>
      )}
    </div>
  );
}