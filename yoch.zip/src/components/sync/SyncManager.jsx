import { useState, useEffect, createContext, useContext, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const SyncContext = createContext(null);

const STORAGE_KEYS = {
  shoots: "pwa_shoots",
  equipment: "pwa_equipment",
  shootEquipment: "pwa_shoot_equipment",
  pendingActions: "pwa_pending_actions",
  lastSync: "pwa_last_sync",
  offlineCache: "pwa_offline_cache"
};

// IndexedDB for larger data storage
const DB_NAME = "ProductionHubOffline";
const DB_VERSION = 1;

const openDB = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      
      if (!db.objectStoreNames.contains("shoots")) {
        db.createObjectStore("shoots", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("equipment")) {
        db.createObjectStore("equipment", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("shootEquipment")) {
        db.createObjectStore("shootEquipment", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("pendingActions")) {
        db.createObjectStore("pendingActions", { keyPath: "id", autoIncrement: true });
      }
    };
  });
};

const saveToIndexedDB = async (storeName, data) => {
  const db = await openDB();
  const tx = db.transaction(storeName, "readwrite");
  const store = tx.objectStore(storeName);
  
  // Clear existing data and add new
  store.clear();
  data.forEach(item => store.put(item));
  
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
};

const getFromIndexedDB = async (storeName) => {
  const db = await openDB();
  const tx = db.transaction(storeName, "readonly");
  const store = tx.objectStore(storeName);
  
  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
};

// Generate temporary IDs for offline records
const generateTempId = () => `temp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

export function SyncProvider({ children }) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState(() => {
    return localStorage.getItem(STORAGE_KEYS.lastSync) || null;
  });
  const [pendingCount, setPendingCount] = useState(() => {
    const pending = JSON.parse(localStorage.getItem(STORAGE_KEYS.pendingActions) || "[]");
    return pending.length;
  });
  const syncTimeoutRef = useRef(null);
  const hasInitialized = useRef(false);

  // Monitor online status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.success("Back online! Syncing data...");
    };
    const handleOffline = () => {
      setIsOnline(false);
      toast.warning("You're offline. Changes will be saved locally.");
    };
    
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Auto-sync when coming online with debounce
  useEffect(() => {
    if (isOnline && hasInitialized.current) {
      if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
      syncTimeoutRef.current = setTimeout(() => {
        syncWithServer();
      }, 1000);
    }
    return () => {
      if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    };
  }, [isOnline]);

  // Get data from local storage (with IndexedDB fallback)
  const getLocalData = useCallback((entityType) => {
    const key = STORAGE_KEYS[entityType];
    const data = localStorage.getItem(key);
    return JSON.parse(data || "[]");
  }, []);

  // Save data to local storage and IndexedDB
  const setLocalData = useCallback(async (entityType, data) => {
    const key = STORAGE_KEYS[entityType];
    localStorage.setItem(key, JSON.stringify(data));
    
    // Also save to IndexedDB for larger storage
    try {
      await saveToIndexedDB(entityType, data);
    } catch (e) {
      console.warn("IndexedDB save failed:", e);
    }
  }, []);

  // Add pending action for sync
  const addPendingAction = useCallback((action) => {
    const pending = JSON.parse(localStorage.getItem(STORAGE_KEYS.pendingActions) || "[]");
    pending.push({ ...action, timestamp: Date.now() });
    localStorage.setItem(STORAGE_KEYS.pendingActions, JSON.stringify(pending));
    setPendingCount(pending.length);
  }, []);

  // Clear pending actions
  const clearPendingActions = useCallback(() => {
    localStorage.setItem(STORAGE_KEYS.pendingActions, "[]");
    setPendingCount(0);
  }, []);

  // Create record (local + queue for sync)
  const createRecord = useCallback(async (entityType, data) => {
    const tempId = generateTempId();
    const record = {
      ...data,
      id: tempId,
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString(),
      _isLocal: true
    };

    // Save locally
    const localData = getLocalData(entityType);
    localData.push(record);
    setLocalData(entityType, localData);

    // Queue for sync
    addPendingAction({
      type: "create",
      entityType,
      tempId,
      data
    });

    // Try immediate sync if online
    if (isOnline) {
      syncWithServer();
    }

    return record;
  }, [isOnline, getLocalData, setLocalData, addPendingAction]);

  // Update record
  const updateRecord = useCallback(async (entityType, id, data) => {
    const localData = getLocalData(entityType);
    const index = localData.findIndex(item => item.id === id);
    
    if (index !== -1) {
      localData[index] = {
        ...localData[index],
        ...data,
        updated_date: new Date().toISOString(),
        _isModified: true
      };
      setLocalData(entityType, localData);
    }

    // Queue for sync (only if not a temp record)
    if (!id.startsWith("temp_")) {
      addPendingAction({
        type: "update",
        entityType,
        id,
        data
      });
    }

    if (isOnline) {
      syncWithServer();
    }

    return localData[index];
  }, [isOnline, getLocalData, setLocalData, addPendingAction]);

  // Delete record
  const deleteRecord = useCallback(async (entityType, id) => {
    const localData = getLocalData(entityType);
    const filtered = localData.filter(item => item.id !== id);
    setLocalData(entityType, filtered);

    // Queue for sync (only if not a temp record)
    if (!id.startsWith("temp_")) {
      addPendingAction({
        type: "delete",
        entityType,
        id
      });
    }

    if (isOnline) {
      syncWithServer();
    }
  }, [isOnline, getLocalData, setLocalData, addPendingAction]);

  // Sync with server
  const syncWithServer = useCallback(async () => {
    if (!isOnline || isSyncing) return;

    setIsSyncing(true);

    try {
      const pending = JSON.parse(localStorage.getItem(STORAGE_KEYS.pendingActions) || "[]");
      const idMapping = {}; // Map temp IDs to real IDs
      let syncedCount = 0;

      // Process pending actions
      for (const action of pending) {
        const entityMap = {
          shoots: base44.entities.Shoot,
          equipment: base44.entities.EquipmentCatalog,
          shootEquipment: base44.entities.ShootEquipment
        };
        const entity = entityMap[action.entityType];

        try {
          if (action.type === "create") {
            // Replace temp IDs in references
            let dataToCreate = { ...action.data };
            if (action.entityType === "shootEquipment") {
              if (idMapping[dataToCreate.shoot]) {
                dataToCreate.shoot = idMapping[dataToCreate.shoot];
              }
              if (idMapping[dataToCreate.equipment]) {
                dataToCreate.equipment = idMapping[dataToCreate.equipment];
              }
            }
            
            const created = await entity.create(dataToCreate);
            idMapping[action.tempId] = created.id;
            syncedCount++;
          } else if (action.type === "update") {
            await entity.update(action.id, action.data);
            syncedCount++;
          } else if (action.type === "delete") {
            await entity.delete(action.id);
            syncedCount++;
          }
        } catch (actionError) {
          console.error("Action failed:", action, actionError);
        }
      }

      // Clear pending actions after successful sync
      clearPendingActions();

      // Fetch fresh data from server with higher limits
      const [shoots, equipment, shootEquipment] = await Promise.all([
        base44.entities.Shoot.list("-date", 500),
        base44.entities.EquipmentCatalog.list("name", 1000),
        base44.entities.ShootEquipment.list("-created_date", 2000)
      ]);

      // Update local storage with server data
      await Promise.all([
        setLocalData("shoots", shoots),
        setLocalData("equipment", equipment),
        setLocalData("shootEquipment", shootEquipment)
      ]);

      // Update last sync time
      const now = new Date().toISOString();
      localStorage.setItem(STORAGE_KEYS.lastSync, now);
      setLastSyncTime(now);

      if (syncedCount > 0) {
        toast.success(`Synced ${syncedCount} changes`);
      }

    } catch (error) {
      console.error("Sync failed:", error);
      toast.error("Sync failed. Will retry when online.");
    } finally {
      setIsSyncing(false);
    }
  }, [isOnline, isSyncing, clearPendingActions, setLocalData]);

  // Initial data load - tries server first, falls back to local
  const loadInitialData = useCallback(async () => {
    hasInitialized.current = true;
    
    if (isOnline) {
      try {
        await syncWithServer();
      } catch (error) {
        console.log("Initial sync failed, using cached data");
        // Try loading from IndexedDB if localStorage is empty
        try {
          const cachedShoots = await getFromIndexedDB("shoots");
          const cachedEquipment = await getFromIndexedDB("equipment");
          const cachedShootEquipment = await getFromIndexedDB("shootEquipment");
          
          if (cachedShoots.length) {
            localStorage.setItem(STORAGE_KEYS.shoots, JSON.stringify(cachedShoots));
          }
          if (cachedEquipment.length) {
            localStorage.setItem(STORAGE_KEYS.equipment, JSON.stringify(cachedEquipment));
          }
          if (cachedShootEquipment.length) {
            localStorage.setItem(STORAGE_KEYS.shootEquipment, JSON.stringify(cachedShootEquipment));
          }
        } catch (e) {
          console.warn("IndexedDB load failed:", e);
        }
      }
    } else {
      // Offline: load from IndexedDB/localStorage
      try {
        const cachedShoots = await getFromIndexedDB("shoots");
        const cachedEquipment = await getFromIndexedDB("equipment");
        const cachedShootEquipment = await getFromIndexedDB("shootEquipment");
        
        if (cachedShoots.length) {
          localStorage.setItem(STORAGE_KEYS.shoots, JSON.stringify(cachedShoots));
        }
        if (cachedEquipment.length) {
          localStorage.setItem(STORAGE_KEYS.equipment, JSON.stringify(cachedEquipment));
        }
        if (cachedShootEquipment.length) {
          localStorage.setItem(STORAGE_KEYS.shootEquipment, JSON.stringify(cachedShootEquipment));
        }
      } catch (e) {
        console.warn("IndexedDB load failed:", e);
      }
    }
  }, [isOnline, syncWithServer]);

  const value = {
    isOnline,
    isSyncing,
    lastSyncTime,
    pendingCount,
    getLocalData,
    createRecord,
    updateRecord,
    deleteRecord,
    syncWithServer,
    loadInitialData
  };

  return (
    <SyncContext.Provider value={value}>
      {children}
    </SyncContext.Provider>
  );
}

export function useSync() {
  const context = useContext(SyncContext);
  if (!context) {
    throw new Error("useSync must be used within a SyncProvider");
  }
  return context;
}