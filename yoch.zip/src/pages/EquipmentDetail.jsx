import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Edit, Loader2, Package, User, Hash, FileText, AlertCircle, Boxes, DollarSign, Banknote } from "lucide-react";
import EditEquipmentDialog from "@/components/equipment/EditEquipmentDialog";

const COLOR_MAP = {
  Blue: "bg-blue-100 text-blue-700",
  Purple: "bg-purple-100 text-purple-700",
  Amber: "bg-amber-100 text-amber-700",
  Green: "bg-green-100 text-green-700",
  Slate: "bg-slate-100 text-slate-700",
  Pink: "bg-pink-100 text-pink-700",
  Orange: "bg-orange-100 text-orange-700",
  Red: "bg-red-100 text-red-700",
  Cyan: "bg-cyan-100 text-cyan-700",
  Indigo: "bg-indigo-100 text-indigo-700"
};

export default function EquipmentDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const equipmentId = urlParams.get("id");

  const [equipment, setEquipment] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [categorySettings, setCategorySettings] = useState({});
  const [isAdmin, setIsAdmin] = useState(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [eq, settings, user] = await Promise.all([
        base44.entities.EquipmentCatalog.filter({ id: equipmentId }),
        base44.entities.CategorySettings.list(),
        base44.auth.me()
      ]);

      if (eq && eq.length > 0) {
        setEquipment(eq[0]);
      }

      const settingsMap = {};
      settings.forEach(s => {
        settingsMap[s.category_key] = s;
      });
      setCategorySettings(settingsMap);
      setIsAdmin(user?.role === "admin");
    } catch (e) {
      console.error(e);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [equipmentId]);

  const getCategoryDisplay = (category) => {
    const setting = categorySettings[category];
    if (setting) {
      return {
        color: COLOR_MAP[setting.color] || "bg-slate-100 text-slate-600",
        label: setting.label || category
      };
    }
    return { color: "bg-slate-100 text-slate-600", label: category || "Другое" };
  };

  const handleEditSaved = () => {
    loadData();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!equipment) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col items-center justify-center">
        <Package className="w-12 h-12 text-slate-300 mb-4" />
        <p className="text-slate-500 mb-4">Оборудование не найдено</p>
        <Link to={createPageUrl("Equipment")}>
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            К каталогу
          </Button>
        </Link>
      </div>
    );
  }

  const catDisplay = getCategoryDisplay(equipment.category);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {/* Back Link */}
        <Link 
          to={createPageUrl("Equipment")}
          className="inline-flex items-center text-sm text-slate-500 hover:text-slate-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Назад к каталогу
        </Link>

        {/* Header Card */}
        <Card className="mb-6 border-slate-200/60 overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <Badge className={`${catDisplay.color} mb-3`}>
                  {catDisplay.label}
                </Badge>
                <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
                  {equipment.name}
                </h1>
                {equipment.sheet_id && (
                  <p className="text-indigo-100 flex items-center gap-2 text-sm">
                    <Hash className="w-4 h-4" />
                    ID: {equipment.sheet_id}
                  </p>
                )}
              </div>
              {isAdmin && (
                <Button 
                  variant="secondary" 
                  onClick={() => setShowEditDialog(true)}
                  className="shrink-0"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Редактировать
                </Button>
              )}
            </div>
          </div>
        </Card>

        {/* Details Card */}
        <Card className="border-slate-200/60">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">
              Информация
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Stock */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0">
                <Boxes className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm text-slate-500">Количество на складе</p>
                <p className="text-lg font-semibold text-slate-900">{equipment.stock || 1} шт.</p>
              </div>
            </div>

            {/* Condition */}
            {equipment.condition && (
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Состояние</p>
                  <p className="text-lg font-medium text-slate-900">{equipment.condition}</p>
                </div>
              </div>
            )}

            {/* Owner */}
            {equipment.owner && (
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center shrink-0">
                  <User className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Владелец / Контакт</p>
                  <p className="text-lg font-medium text-slate-900">{equipment.owner}</p>
                </div>
              </div>
            )}

            {/* Rent Price */}
            {equipment.rent_price > 0 && (
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0">
                  <DollarSign className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Цена аренды</p>
                  <p className="text-lg font-semibold text-indigo-600">{equipment.rent_price.toLocaleString()} ₽/день</p>
                </div>
              </div>
            )}

            {/* Full Price */}
            {equipment.price > 0 && (
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
                  <Banknote className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Полная стоимость</p>
                  <p className="text-lg font-semibold text-emerald-600">{equipment.price.toLocaleString()} ₽</p>
                </div>
              </div>
            )}

            {/* Description */}
            {equipment.description && (
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Описание / Комментарий</p>
                  <p className="text-slate-900 whitespace-pre-wrap">{equipment.description}</p>
                </div>
              </div>
            )}

            {/* No additional info */}
            {!equipment.condition && !equipment.owner && !equipment.description && !equipment.rent_price && !equipment.price && (
              <p className="text-slate-500 text-center py-4">
                Дополнительная информация отсутствует
              </p>
            )}
          </CardContent>
        </Card>

        <EditEquipmentDialog
          open={showEditDialog}
          onClose={() => setShowEditDialog(false)}
          equipment={equipment}
          onSaved={handleEditSaved}
        />
      </div>
    </div>
  );
}