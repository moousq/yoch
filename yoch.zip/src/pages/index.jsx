import Layout from "./Layout.jsx";

import Equipment from "./Equipment";

import ShootDetail from "./ShootDetail";

import Profile from "./Profile";

import Home from "./Home";

import Notifications from "./Notifications";

import EquipmentDetail from "./EquipmentDetail";

import Settings from "./Settings";

import Checklist from "./Checklist";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Equipment: Equipment,
    
    ShootDetail: ShootDetail,
    
    Profile: Profile,
    
    Home: Home,
    
    Notifications: Notifications,
    
    EquipmentDetail: EquipmentDetail,
    
    Settings: Settings,
    
    Checklist: Checklist,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Equipment />} />
                
                
                <Route path="/Equipment" element={<Equipment />} />
                
                <Route path="/ShootDetail" element={<ShootDetail />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/EquipmentDetail" element={<EquipmentDetail />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Checklist" element={<Checklist />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}