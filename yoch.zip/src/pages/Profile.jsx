import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Mail, Calendar, LogOut, Save, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { toast } from "sonner";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [fullName, setFullName] = useState("");

  useEffect(() => {
    const load = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        setFullName(userData?.full_name || "");
      } catch (e) {
        console.error(e);
      }
      setIsLoading(false);
    };
    load();
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await base44.auth.updateMe({ full_name: fullName });
      toast.success("Профиль обновлён");
    } catch (e) {
      toast.error("Ошибка сохранения");
    }
    setIsSaving(false);
  };

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-lg mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">Профиль</h1>

        <Card className="mb-6">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="w-5 h-5 text-indigo-600" />
              Личные данные
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Имя</label>
              <Input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Ваше имя"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Email</label>
              <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-md text-slate-600">
                <Mail className="w-4 h-4" />
                {user?.email}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Роль</label>
              <div className="px-3 py-2 bg-slate-50 rounded-md text-slate-600 capitalize">
                {user?.role === "admin" ? "Администратор" : "Пользователь"}
              </div>
            </div>

            {user?.created_date && (
              <div>
                <label className="text-sm font-medium text-slate-700 mb-1.5 block">Дата регистрации</label>
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-md text-slate-600">
                  <Calendar className="w-4 h-4" />
                  {format(new Date(user.created_date), "d MMMM yyyy", { locale: ru })}
                </div>
              </div>
            )}

            <Button 
              onClick={handleSave} 
              disabled={isSaving}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              Сохранить
            </Button>
          </CardContent>
        </Card>

        <Button 
          variant="outline" 
          onClick={handleLogout}
          className="w-full text-red-600 border-red-200 hover:bg-red-50"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Выйти
        </Button>
      </div>
    </div>
  );
}