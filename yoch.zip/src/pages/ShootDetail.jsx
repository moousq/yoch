import { useState, useEffect } from "react";
import { useSync } from "@/components/sync/SyncManager";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Plus, ArrowLeft, Trash2, Loader2, Package, CloudOff, Clock, CheckCircle, XCircle, Download, Play, FileCheck, Ban, Minus, MoreVertical, Edit } from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ShootForm from "@/components/shoots/ShootForm";
import AddEquipmentToShoot from "@/components/equipment/AddEquipmentToShoot";
import ExportFieldsDialog from "@/components/equipment/ExportFieldsDialog";
import SyncStatusBar from "@/components/sync/SyncStatusBar";
import ShootChat from "@/components/shoots/ShootChat";
import ShootEquipmentList from "@/components/equipment/ShootEquipmentList";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";

const statusConfig = {
  draft: { label: "Черновик", icon: Clock, color: "bg-slate-100 text-slate-700 border-slate-200" },
  pending: { label: "Ожидает подтверждения", icon: Clock, color: "bg-amber-100 text-amber-700 border-amber-200" },
  approved: { label: "Одобрено", icon: CheckCircle, color: "bg-green-100 text-green-700 border-green-200" },
  in_progress: { label: "В работе", icon: Play, color: "bg-blue-100 text-blue-700 border-blue-200" },
  completed: { label: "Завершено", icon: FileCheck, color: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  rejected: { label: "Отклонено", icon: XCircle, color: "bg-red-100 text-red-700 border-red-200" },
  cancelled: { label: "Отменено", icon: Ban, color: "bg-gray-100 text-gray-700 border-gray-200" }
};

export default function ShootDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const shootId = urlParams.get("id");
  
  const [showEditForm, setShowEditForm] = useState(false);
  const [showAddEquipment, setShowAddEquipment] = useState(false);
  const [shoot, setShoot] = useState(null);
  const [shootEquipment, setShootEquipment] = useState([]);
  const [equipmentCatalog, setEquipmentCatalog] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminComment, setAdminComment] = useState("");
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showClearEquipmentDialog, setShowClearEquipmentDialog] = useState(false);
  const [isClearingEquipment, setIsClearingEquipment] = useState(false);
  const [clearProgress, setClearProgress] = useState({ current: 0, total: 0 });
  
  const navigate = useNavigate();
  const { getLocalData, createRecord, updateRecord, deleteRecord, loadInitialData } = useSync();

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      await loadInitialData();
      
      const shoots = getLocalData("shoots");
      const found = shoots.find(s => s.id === shootId);
      setShoot(found);
      setAdminComment(found?.admin_comment || "");
      
      const allShootEquipment = getLocalData("shootEquipment");
      setShootEquipment(allShootEquipment.filter(se => se.shoot === shootId));
      
      setEquipmentCatalog(getLocalData("equipment"));
      
      // Check admin
      try {
        const user = await base44.auth.me();
        setIsAdmin(user?.role === "admin");
      } catch (e) {
        setIsAdmin(false);
      }
      
      setIsLoading(false);
    };
    load();
  }, [shootId]);

  // Refresh local data periodically
  useEffect(() => {
    const interval = setInterval(() => {
      const shoots = getLocalData("shoots");
      const found = shoots.find(s => s.id === shootId);
      setShoot(found);
      
      const allShootEquipment = getLocalData("shootEquipment");
      setShootEquipment(allShootEquipment.filter(se => se.shoot === shootId));
      
      setEquipmentCatalog(getLocalData("equipment"));
    }, 1000);
    return () => clearInterval(interval);
  }, [shootId, getLocalData]);

  const handleUpdateShoot = async (data) => {
    await updateRecord("shoots", shootId, data);
    // Reload to get fresh data
    await loadInitialData();
  };

  const handleAddEquipment = async (data) => {
    // Fetch fresh data from server to get current state
    const freshEquipment = await base44.entities.ShootEquipment.filter({ shoot: shootId });
    
    // Check if equipment with same ID already exists
    const existing = freshEquipment.find(se => se.equipment === data.equipment);
    
    if (existing) {
      // Calculate total quantity if we update
      const newTotalQty = (existing.quantity || 1) + (data.quantity || 1);
      
      // Check against catalog stock for this specific item
      const catalogItem = equipmentCatalog.find(e => e.id === data.equipment);
      const availableStock = catalogItem?.stock || 1;
      
      if (newTotalQty > availableStock) {
        toast.error(`Недостаточно оборудования в наличии (доступно: ${availableStock})`);
        return;
      }
      
      // Update quantity
      await base44.entities.ShootEquipment.update(existing.id, {
        quantity: newTotalQty
      });
    } else {
      // Check stock before creating new entry
      const catalogItem = equipmentCatalog.find(e => e.id === data.equipment);
      const availableStock = catalogItem?.stock || 1;
      
      if (data.quantity > availableStock) {
        toast.error(`Недостаточно оборудования в наличии (доступно: ${availableStock})`);
        return;
      }
      
      await base44.entities.ShootEquipment.create({ ...data, shoot: shootId });
    }
    
    // Reload data
    await loadInitialData();
  };

  const handleClearAllEquipment = async () => {
    setIsClearingEquipment(true);
    const itemsToDelete = shootEquipment.filter(eq => !eq.id?.startsWith("temp_"));
    setClearProgress({ current: 0, total: itemsToDelete.length });

    try {
      // Delete in parallel batches of 10 for speed
      const BATCH_SIZE = 10;
      for (let i = 0; i < itemsToDelete.length; i += BATCH_SIZE) {
        const batch = itemsToDelete.slice(i, i + BATCH_SIZE);
        await Promise.all(batch.map(eq => base44.entities.ShootEquipment.delete(eq.id)));
        setClearProgress({ current: Math.min(i + BATCH_SIZE, itemsToDelete.length), total: itemsToDelete.length });
      }
      // Reload data
      await loadInitialData();
      toast.success("Список очищен");
    } catch (e) {
      toast.error("Ошибка при очистке");
    }
    setIsClearingEquipment(false);
    setClearProgress({ current: 0, total: 0 });
    setShowClearEquipmentDialog(false);
  };

  const handleRemoveEquipment = async (id) => {
    await deleteRecord("shootEquipment", id);
  };

  const handleUpdateEquipmentQuantity = async (id, delta) => {
    const eq = shootEquipment.find(e => e.id === id);
    if (!eq) return;
    const newQty = Math.max(1, (eq.quantity || 1) + delta);
    await updateRecord("shootEquipment", id, { quantity: newQty });
  };

  const handleExportPDF = async (fields) => {
    setIsExporting(true);
    setShowExportDialog(false);
    try {
      const response = await base44.functions.invoke('exportEquipmentList', {
                  shootId: shootId,
                  shootShortId: shootId?.slice(-6).toUpperCase(),
                  shootTitle: shoot.title,
                  shootDate: shoot.date ? (
                    shoot.end_date && shoot.end_date !== shoot.date
                      ? `${format(new Date(shoot.date), "d MMM", { locale: ru })} – ${format(new Date(shoot.end_date), "d MMMM yyyy", { locale: ru })}`
                      : format(new Date(shoot.date), "d MMMM yyyy", { locale: ru })
                  ) : null,
                  shootLocation: shoot.location || '',
                  shootResponsible: shoot.responsible || '',
                  fields: fields,
                  equipment: shootEquipment.map(eq => {
                                  const catalogItem = equipmentCatalog.find(e => e.id === eq.equipment);
                                  // Find all IDs for items with same name
                                  const allIds = equipmentCatalog
                                    .filter(e => e.name?.toLowerCase().trim() === eq.equipment_name?.toLowerCase().trim())
                                    .map(e => e.sheet_id)
                                    .filter(Boolean);
                                  return {
                                    name: eq.equipment_name,
                                    sheet_id: allIds.length > 0 ? allIds.join(', ') : '',
                                    category: catalogItem?.category || '',
                                    quantity: eq.quantity || 1,
                                    days: eq.days || 1,
                                    rent_price: eq.rent_price || 0,
                                    line_total: (eq.quantity || 1) * (eq.days || 1) * (eq.rent_price || 0),
                                    condition: catalogItem?.condition || '',
                                    owner: catalogItem?.owner || '',
                                    price: catalogItem?.price || 0,
                                    comment: eq.comment || ''
                                  };
                                })
                });

      // Safari-compatible: use hidden iframe instead of new window
      const htmlContent = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
      const iframe = document.createElement('iframe');
      iframe.style.position = 'absolute';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = 'none';
      document.body.appendChild(iframe);

      const iframeDoc = iframe.contentWindow.document;
      iframeDoc.open();
      iframeDoc.write(htmlContent);
      iframeDoc.close();

      // Set page title for print
      if (shoot.title) {
        const dateStr = shoot.date ? (
          shoot.end_date && shoot.end_date !== shoot.date
            ? `${format(new Date(shoot.date), "d MMM", { locale: ru })} – ${format(new Date(shoot.end_date), "d MMM yyyy", { locale: ru })}`
            : format(new Date(shoot.date), "d MMMM yyyy", { locale: ru })
        ) : '';
        document.title = `${shoot.title}${dateStr ? ' – ' + dateStr : ''}`;
      }

      // Wait for content to load, then print
      iframe.onload = () => {
        setTimeout(() => {
          iframe.contentWindow.print();
          // Clean up after print dialog closes
          setTimeout(() => {
            document.body.removeChild(iframe);
          }, 1000);
        }, 100);
      };

      toast.success("Открываю печать...");
    } catch (e) {
      toast.error("Ошибка при экспорте");
    }
    setIsExporting(false);
  };

  const handleDeleteShoot = async () => {
    setIsDeleting(true);
    try {
      // Delete all equipment in parallel batches
      const BATCH_SIZE = 10;
      for (let i = 0; i < shootEquipment.length; i += BATCH_SIZE) {
        const batch = shootEquipment.slice(i, i + BATCH_SIZE);
        await Promise.all(batch.map(eq => base44.entities.ShootEquipment.delete(eq.id)));
      }
      // Delete shoot
      await base44.entities.Shoot.delete(shootId);
      toast.success("Заявка удалена");
      navigate(createPageUrl("Home"));
    } catch (e) {
      toast.error("Ошибка при удалении");
    }
    setIsDeleting(false);
  };

  const handleStatusChange = async (newStatus) => {
    setIsUpdatingStatus(true);
    try {
      await base44.entities.Shoot.update(shootId, {
        status: newStatus,
        admin_comment: adminComment
      });
      
      // Create notification for shoot owner
      if (shoot.created_by) {
        await base44.entities.Notification.create({
          user_email: shoot.created_by,
          title: newStatus === "approved" ? "Заявка одобрена" : "Заявка отклонена",
          message: `Ваша заявка "${shoot.title}" была ${newStatus === "approved" ? "одобрена" : "отклонена"}${adminComment ? `. Комментарий: ${adminComment}` : ""}`,
          type: "status_change",
          shoot_id: shootId
        });
      }
      
      setShoot({ ...shoot, status: newStatus, admin_comment: adminComment });
      toast.success(newStatus === "approved" ? "Заявка одобрена" : "Заявка отклонена");
      await loadInitialData();
    } catch (e) {
      toast.error("Ошибка при обновлении статуса");
    }
    setIsUpdatingStatus(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col">
        <SyncStatusBar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  if (!shoot) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col">
        <SyncStatusBar />
        <div className="flex-1 flex flex-col items-center justify-center">
          <p className="text-slate-500 mb-4">Shoot not found</p>
          <Link to={createPageUrl("Home")}>
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Назад к заявкам
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const isLocal = shoot._isLocal || shoot.id?.startsWith("temp_");
  const status = shoot.status || "pending";
  const StatusIcon = statusConfig[status]?.icon || Clock;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col">
      <SyncStatusBar />
      
      <div className="flex-1 max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12 w-full">
        {/* Back Link */}
        <Link 
          to={createPageUrl("Home")}
          className="inline-flex items-center text-sm text-slate-500 hover:text-slate-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Назад к заявкам
        </Link>

        {/* Header Card */}
        <Card className="mb-6 border-slate-200/60 overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 sm:p-8">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                            <div>
                              <div className="flex flex-wrap gap-2 mb-3">
                                <Badge className="bg-white/20 text-white border-white/30 font-mono text-xs">
                                  #{shootId?.slice(-6).toUpperCase()}
                                </Badge>
                                {isLocal && (
                                  <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                                    <CloudOff className="w-3 h-3 mr-1" />
                                    Локально
                                  </Badge>
                                )}
                                <Badge className={statusConfig[status]?.color}>
                                  <StatusIcon className="w-3 h-3 mr-1" />
                                  {statusConfig[status]?.label}
                                </Badge>
                                {shoot.created_date && (
                                  <Badge className="bg-white/20 text-white border-white/30 text-xs">
                                    {format(new Date(shoot.created_date), "d MMM yyyy, HH:mm", { locale: ru })}
                                  </Badge>
                                )}
                              </div>
                              <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
                                {shoot.title}
                              </h1>
                {shoot.date && (
                  <p className="text-indigo-100 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {shoot.end_date && shoot.end_date !== shoot.date
                      ? `${format(new Date(shoot.date), "d MMM", { locale: ru })} – ${format(new Date(shoot.end_date), "d MMMM yyyy", { locale: ru })}`
                      : format(new Date(shoot.date), "d MMMM yyyy", { locale: ru })
                    }
                  </p>
                )}
                {shoot.responsible && (
                  <p className="text-indigo-100 mt-1">Ответственный: {shoot.responsible}</p>
                )}
                {shoot.location && (
                  <p className="text-indigo-100 mt-1">Локация: {shoot.location}</p>
                )}
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="secondary" 
                  onClick={() => setShowEditForm(true)}
                  className="shrink-0"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Редактировать
                </Button>
                {isAdmin && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="secondary" size="icon" className="shrink-0">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => setShowDeleteDialog(true)} className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Удалить заявку
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* Admin Actions */}
        {isAdmin && (
          <Card className="mb-6 border-slate-200/60">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-slate-900">
                Управление заявкой
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-700 mb-1.5 block">
                  Статус заявки
                </label>
                <Select value={status} onValueChange={(val) => handleStatusChange(val)}>
                  <SelectTrigger className="w-full sm:w-64">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Черновик</SelectItem>
                    <SelectItem value="pending">Ожидает подтверждения</SelectItem>
                    <SelectItem value="approved">Одобрено</SelectItem>
                    <SelectItem value="in_progress">В работе</SelectItem>
                    <SelectItem value="completed">Завершено</SelectItem>
                    <SelectItem value="rejected">Отклонено</SelectItem>
                    <SelectItem value="cancelled">Отменено</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 mb-1.5 block">
                  Комментарий (необязательно)
                </label>
                <Textarea
                  placeholder="Добавьте комментарий..."
                  value={adminComment}
                  onChange={(e) => setAdminComment(e.target.value)}
                  className="bg-slate-50"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Admin Comment Display */}
        {shoot.admin_comment && status !== "pending" && (
          <Card className="mb-6 border-slate-200/60">
            <CardContent className="p-4">
              <p className="text-sm text-slate-600">
                <span className="font-medium">Комментарий:</span> {shoot.admin_comment}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Equipment Section */}
        <Card className="border-slate-200/60">
          <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-3">
                      <div>
                        <CardTitle className="text-lg font-semibold text-slate-900">
                          Оборудование ({shootEquipment.length})
                        </CardTitle>
                        {shootEquipment.some(eq => eq.rent_price > 0) && (() => {
                          const shootDays = shoot?.date && shoot?.end_date && shoot.end_date !== shoot.date
                            ? Math.max(1, Math.ceil((new Date(shoot.end_date) - new Date(shoot.date)) / (1000 * 60 * 60 * 24)) + 1)
                            : 1;
                          const total = shootEquipment.reduce((sum, eq) => {
                            const days = eq.days || shootDays;
                            return sum + ((eq.quantity || 1) * days * (eq.rent_price || 0));
                          }, 0);
                          return (
                            <p className="text-sm text-indigo-600 font-medium mt-1">
                              Итого: {total.toLocaleString()} ₽
                            </p>
                          );
                        })()}
                      </div>
                          <div className="flex flex-wrap gap-2">
                            <Button 
                              onClick={() => setShowAddEquipment(true)}
                              size="sm"
                              className="bg-indigo-600 hover:bg-indigo-700"
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Добавить
                            </Button>
                            {shootEquipment.length > 0 && (
                              <>
                                <Link to={createPageUrl("Checklist") + `?id=${shootId}`}>
                                  <Button 
                                    size="sm"
                                    className="bg-emerald-600 hover:bg-emerald-700"
                                  >
                                    <CheckCircle className="w-4 h-4 mr-2" />
                                    Чек-лист
                                  </Button>
                                </Link>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button size="sm" variant="outline">
                                      <MoreVertical className="w-4 h-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => setShowExportDialog(true)} disabled={isExporting}>
                                      <Download className="w-4 h-4 mr-2" />
                                      Экспорт PDF
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onClick={() => setShowClearEquipmentDialog(true)} className="text-red-600">
                                      <Trash2 className="w-4 h-4 mr-2" />
                                      Очистить список
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </>
                            )}
                          </div>
                        </CardHeader>
          <CardContent>
            {shootEquipment.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-lg">
                <Package className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500 mb-3">Оборудование не добавлено</p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowAddEquipment(true)}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Добавить
                </Button>
              </div>
            ) : (
                          <ShootEquipmentList
                            shootEquipment={shootEquipment}
                            equipmentCatalog={equipmentCatalog}
                            shoot={shoot}
                            onRemove={handleRemoveEquipment}
                            onUpdateQuantity={handleUpdateEquipmentQuantity}
                            getMaxQuantity={(equipmentId) => {
                              const catalogItem = equipmentCatalog.find(e => e.id === equipmentId);
                              return catalogItem?.stock || 1;
                            }}
                            isAdmin={isAdmin}
                          />
                        )}
          </CardContent>
        </Card>

        <ShootForm
          open={showEditForm}
          onClose={() => setShowEditForm(false)}
          onSubmit={handleUpdateShoot}
          shoot={shoot}
        />

        {/* Chat Section */}
        <div className="mt-6">
          <ShootChat shootId={shootId} isAdmin={isAdmin} />
        </div>

        <AddEquipmentToShoot
          open={showAddEquipment}
          onClose={() => setShowAddEquipment(false)}
          onSubmit={handleAddEquipment}
          equipmentCatalog={equipmentCatalog}
          shootEquipment={shootEquipment}
          isLoadingCatalog={false}
          shootDays={shoot?.date && shoot?.end_date && shoot.end_date !== shoot.date
            ? Math.max(1, Math.ceil((new Date(shoot.end_date) - new Date(shoot.date)) / (1000 * 60 * 60 * 24)) + 1)
            : 1
          }
        />

        <ExportFieldsDialog
          open={showExportDialog}
          onClose={() => setShowExportDialog(false)}
          onExport={handleExportPDF}
          isExporting={isExporting}
        />

        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить заявку?</AlertDialogTitle>
              <AlertDialogDescription>
                Заявка "{shoot.title}" и всё связанное оборудование будут удалены. Это действие нельзя отменить.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отмена</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleDeleteShoot} 
                className="bg-red-600 hover:bg-red-700"
                disabled={isDeleting}
              >
                {isDeleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Удалить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <AlertDialog open={showClearEquipmentDialog} onOpenChange={setShowClearEquipmentDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Очистить список оборудования?</AlertDialogTitle>
              <AlertDialogDescription>
                Всё оборудование ({shootEquipment.length} поз.) будет удалено из заявки.
              </AlertDialogDescription>
            </AlertDialogHeader>
            {isClearingEquipment && clearProgress.total > 0 && (
              <div className="space-y-2 py-2">
                <Progress value={(clearProgress.current / clearProgress.total) * 100} className="h-2" />
                <p className="text-sm text-slate-500 text-center">
                  Удалено {clearProgress.current} из {clearProgress.total}
                </p>
              </div>
            )}
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isClearingEquipment}>Отмена</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleClearAllEquipment} 
                className="bg-red-600 hover:bg-red-700"
                disabled={isClearingEquipment}
              >
                {isClearingEquipment ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Очистить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}