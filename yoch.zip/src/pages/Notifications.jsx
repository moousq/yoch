import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bell, CheckCircle, XCircle, MessageSquare, Info, Check, Loader2, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

const typeConfig = {
  status_change: { icon: CheckCircle, color: "text-green-600 bg-green-50", label: "Изменение статуса" },
  assignment: { icon: Info, color: "text-blue-600 bg-blue-50", label: "Назначение" },
  message: { icon: MessageSquare, color: "text-purple-600 bg-purple-50", label: "Сообщение" },
  info: { icon: Info, color: "text-slate-600 bg-slate-50", label: "Информация" }
};

export default function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const user = await base44.auth.me();
        if (user?.email) {
          const notifs = await base44.entities.Notification.filter(
            { user_email: user.email },
            "-created_date",
            100
          );
          setNotifications(notifs);
        }
      } catch (e) {
        console.error(e);
      }
      setIsLoading(false);
    };
    load();
  }, []);

  const markAsRead = async (id) => {
    await base44.entities.Notification.update(id, { is_read: true });
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, is_read: true } : n)
    );
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.is_read);
    await Promise.all(unread.map(n => 
      base44.entities.Notification.update(n.id, { is_read: true })
    ));
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    toast.success("Все уведомления прочитаны");
  };

  const deleteNotification = async (id) => {
    await base44.entities.Notification.delete(id);
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Уведомления</h1>
            {unreadCount > 0 && (
              <p className="text-slate-500 mt-1">{unreadCount} непрочитанных</p>
            )}
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              <Check className="w-4 h-4 mr-2" />
              Прочитать все
            </Button>
          )}
        </div>

        {notifications.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-1">Нет уведомлений</h3>
            <p className="text-slate-500">Уведомления появятся здесь</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map(notif => {
              const TypeIcon = typeConfig[notif.type]?.icon || Info;
              const colorClass = typeConfig[notif.type]?.color || "text-slate-600 bg-slate-50";
              
              return (
                <Card 
                  key={notif.id} 
                  className={`overflow-hidden transition-all ${!notif.is_read ? "ring-2 ring-indigo-100 bg-indigo-50/30" : ""}`}
                >
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${colorClass}`}>
                        <TypeIcon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="font-semibold text-slate-900">{notif.title}</p>
                            <p className="text-slate-600 mt-0.5">{notif.message}</p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            {!notif.is_read && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8"
                                onClick={() => markAsRead(notif.id)}
                              >
                                <Check className="w-4 h-4" />
                              </Button>
                            )}
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-slate-400 hover:text-red-500"
                              onClick={() => deleteNotification(notif.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-xs text-slate-400">
                            {format(new Date(notif.created_date), "d MMMM yyyy, HH:mm", { locale: ru })}
                          </span>
                          {notif.shoot_id && (
                            <Link 
                              to={createPageUrl(`ShootDetail?id=${notif.shoot_id}`)}
                              className="text-xs text-indigo-600 hover:underline"
                            >
                              Открыть заявку →
                            </Link>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}