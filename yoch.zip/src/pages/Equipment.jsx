import { useState, useEffect } from "react";
import { useSync } from "@/components/sync/SyncManager";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  Plus, Search, Package, Loader2, ShoppingCart, Minus, Trash2, X, Pencil, Calendar as CalendarIcon, Eye, ArrowUpDown, Hash, EyeOff,
  Camera, Circle, Lightbulb, Mic, Wrench, Box, Sparkles, Video, HardDrive, Cpu, Monitor, Headphones, Radio, Zap, Cable, Palette, Clapperboard, Film, Aperture,
  CircleDot, Glasses, Contrast, SlidersHorizontal, Disc,
  Volume2, Volume1, Speaker, Music, AudioLines, AudioWaveform, Megaphone, Podcast,
  Sun, Moon, Flashlight, Flame, Sunrise,
  Battery, BatteryCharging, BatteryFull, Plug, Power, CircuitBoard, Gauge,
  Tv, Laptop, Tablet, Smartphone, Projector, ScreenShare, Airplay,
  Database, Server, Save, Usb,
  Wifi, Bluetooth, Cast, Signal, Router,
  Move, Orbit, RotateCcw, RotateCw, Anchor, Locate, Crosshair, Target,
  Grip, Grid, Layers, Layout, Maximize, Minimize, Shrink, Hand,
  Backpack, Briefcase, Archive, FolderOpen, Truck, Car,
  Settings, Cog, Scissors, Ruler, PenTool, Brush, Eraser,
  Plane, Navigation, Compass, Map, Gamepad2, Joystick,
  Tent, Mountain, TreePine, CloudSun, Droplet, Wind, Snowflake, Thermometer,
  Star, Heart, Shield, Key, Gem, Crown, Award, Medal, Trophy, Square, Hexagon, Triangle, Scan
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import SyncStatusBar from "@/components/sync/SyncStatusBar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import EditEquipmentDialog from "@/components/equipment/EditEquipmentDialog";

const ICON_MAP = {
  Camera, Circle, Lightbulb, Mic, Wrench, Box, Sparkles, Package, Video, HardDrive, Cpu, Monitor, Headphones, Radio, Zap, Cable, Palette, Clapperboard, Film, Aperture,
  CircleDot, Glasses, Contrast, SlidersHorizontal, Disc,
  Volume2, Volume1, Speaker, Music, AudioLines, AudioWaveform, Megaphone, Podcast,
  Sun, Moon, Flashlight, Flame, Sunrise,
  Battery, BatteryCharging, BatteryFull, Plug, Power, CircuitBoard, Gauge,
  Tv, Laptop, Tablet, Smartphone, Projector, ScreenShare, Airplay,
  Database, Server, Save, Usb,
  Wifi, Bluetooth, Cast, Signal, Router,
  Move, Orbit, RotateCcw, RotateCw, Anchor, Locate, Crosshair, Target,
  Grip, Grid, Layers, Layout, Maximize, Minimize, Shrink, Hand,
  Backpack, Briefcase, Archive, FolderOpen, Truck, Car,
  Settings, Cog, Scissors, Ruler, PenTool, Brush, Eraser,
  Plane, Navigation, Compass, Map, Gamepad2, Joystick,
  Tent, Mountain, TreePine, CloudSun, Droplet, Wind, Snowflake, Thermometer,
  Eye, Star, Heart, Shield, Key, Gem, Crown, Award, Medal, Trophy, Square, Hexagon, Triangle, Scan
};

const COLOR_MAP = {
  Blue: "bg-blue-100 text-blue-700",
  Indigo: "bg-indigo-100 text-indigo-700",
  Violet: "bg-violet-100 text-violet-700",
  Sky: "bg-sky-100 text-sky-700",
  Cyan: "bg-cyan-100 text-cyan-700",
  Purple: "bg-purple-100 text-purple-700",
  Fuchsia: "bg-fuchsia-100 text-fuchsia-700",
  Pink: "bg-pink-100 text-pink-700",
  Rose: "bg-rose-100 text-rose-700",
  Red: "bg-red-100 text-red-700",
  Orange: "bg-orange-100 text-orange-700",
  Amber: "bg-amber-100 text-amber-700",
  Yellow: "bg-yellow-100 text-yellow-700",
  Lime: "bg-lime-100 text-lime-700",
  Green: "bg-green-100 text-green-700",
  Emerald: "bg-emerald-100 text-emerald-700",
  Teal: "bg-teal-100 text-teal-700",
  Slate: "bg-slate-100 text-slate-700",
  Gray: "bg-gray-100 text-gray-700",
  Zinc: "bg-zinc-100 text-zinc-700",
  Stone: "bg-stone-100 text-stone-700"
};

export default function Equipment() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [ownerFilters, setOwnerFilters] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [cart, setCart] = useState([]);
  const [categories, setCategories] = useState([]);
  const [owners, setOwners] = useState([]);
  const [categorySettings, setCategorySettings] = useState({});
  const [isAdmin, setIsAdmin] = useState(false);
  const [editingEquipment, setEditingEquipment] = useState(null);
  // Read prefilled data from URL params (from QuickRequestForm)
  const urlParams = new URLSearchParams(window.location.search);
  const prefilledTitle = urlParams.get("title") || "";
  const prefilledFrom = urlParams.get("from");
  const prefilledTo = urlParams.get("to");
  const prefilledResponsible = urlParams.get("responsible") || "";
  
  const [dateRange, setDateRange] = useState({ 
    from: prefilledFrom ? new Date(prefilledFrom) : undefined, 
    to: prefilledTo ? new Date(prefilledTo) : (prefilledFrom ? new Date(prefilledFrom) : undefined)
  });
  const [shootTitle, setShootTitle] = useState(prefilledTitle);
  const [shootLocation, setShootLocation] = useState("");
  const [shootResponsible, setShootResponsible] = useState(prefilledResponsible);
  const [currentUser, setCurrentUser] = useState(null);
  const [shoots, setShoots] = useState([]);
  const [shootEquipment, setShootEquipment] = useState([]);
  const [showClearCartAlert, setShowClearCartAlert] = useState(false);
  const [itemToRemove, setItemToRemove] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [showSheetId, setShowSheetId] = useState(false);
  const [sortBy, setSortBy] = useState("name");
  const [showHidden, setShowHidden] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitProgress, setSubmitProgress] = useState({ current: 0, total: 0 });
  
  const { getLocalData, loadInitialData } = useSync();
  const navigate = useNavigate();

  const getCategoryDisplay = (category) => {
    const setting = categorySettings[category];
    if (setting) {
      return {
        icon: ICON_MAP[setting.icon] || Package,
        color: COLOR_MAP[setting.color] || "bg-slate-100 text-slate-600",
        label: setting.label || category
      };
    }
    return { icon: Package, color: "bg-slate-100 text-slate-600", label: category || "Другое" };
  };

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      await loadInitialData();
      const eq = getLocalData("equipment");
      setEquipment(eq);
      setShoots(getLocalData("shoots"));
      setShootEquipment(getLocalData("shootEquipment"));
      
      // Find most recent updated_date from equipment
      if (eq.length > 0) {
        const dates = eq.map(e => e.updated_date).filter(Boolean);
        if (dates.length > 0) {
          const mostRecent = dates.sort().reverse()[0];
          setLastUpdated(new Date(mostRecent));
        }
      }
      
      // Extract unique categories and owners
      const uniqueCats = [...new Set(eq.map(e => e.category).filter(Boolean))];
      setCategories(uniqueCats);
      
      const uniqueOwners = [...new Set(eq.map(e => e.owner).filter(Boolean))];
      setOwners(uniqueOwners);
      
      // Load category settings
      try {
        const settings = await base44.entities.CategorySettings.list();
        const settingsMap = {};
        settings.forEach(s => {
          settingsMap[s.category_key] = s;
        });
        setCategorySettings(settingsMap);
      } catch (e) {
        console.error("Failed to load category settings:", e);
      }
      
      // Check admin and set user
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        setIsAdmin(user?.role === "admin");
        // Only set responsible from user if not prefilled from URL
        if (user?.full_name && !prefilledResponsible) {
          setShootResponsible(user.full_name);
        }
      } catch (e) {
        setIsAdmin(false);
      }
      
      setIsLoading(false);
    };
    load();
  }, []);

  // Refresh local data periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setEquipment(getLocalData("equipment"));
      setShoots(getLocalData("shoots"));
      setShootEquipment(getLocalData("shootEquipment"));
    }, 1000);
    return () => clearInterval(interval);
  }, [getLocalData]);

  // Calculate booked quantity for equipment on selected date range (supports grouped items)
  const getBookedQuantity = (ids) => {
    const idsArray = Array.isArray(ids) ? ids : [ids];
    const fromDate = dateRange.from ? format(dateRange.from, "yyyy-MM-dd") : null;
    const toDate = dateRange.to ? format(dateRange.to, "yyyy-MM-dd") : fromDate;
    
    if (!fromDate) return 0;
    
    // Find shoots that overlap with selected date range
    const shootsInRange = shoots.filter(s => {
      if (!s.date) return false;
      const shootStart = s.date;
      const shootEnd = s.end_date || s.date;
      // Check for date range overlap
      return shootStart <= toDate && shootEnd >= fromDate;
    });
    const shootIds = shootsInRange.map(s => s.id);
    // Sum quantities for all equipment IDs in those shoots
    return shootEquipment
      .filter(se => shootIds.includes(se.shoot) && idsArray.includes(se.equipment))
      .reduce((sum, se) => sum + (se.quantity || 1), 0);
  };

  // Get available quantity (stock - booked - in cart)
  const getAvailableQuantity = (eq) => {
    const stock = eq.stock || 1;
    const ids = eq.ids || [eq.id];
    const booked = getBookedQuantity(ids);
    const inCart = getCartItemQuantity(ids);
    return Math.max(0, stock - booked - inCart);
  };

  const addToCart = (item) => {
    const available = getAvailableQuantity(item);
    if (available <= 0) {
      toast.error(`${item.name} недоступно на эту дату`);
      return;
    }
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id);
      if (existing) {
        return prev.map(c => 
          c.id === item.id 
            ? { ...c, quantity: c.quantity + 1 }
            : c
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    toast.success(`${item.name} добавлено в корзину`);
  };

  const updateCartQuantity = (itemId, delta) => {
    setCart(prev => {
      return prev.map(c => {
        if (c.id === itemId) {
          const newQty = c.quantity + delta;
          if (newQty <= 0) return null;
          
          // Check max available for grouped item
          if (delta > 0) {
            const stock = c.stock || 1;
            const booked = getBookedQuantity(c.ids || [c.id]);
            const maxAvailable = stock - booked;
            if (newQty > maxAvailable) {
              toast.error(`Больше нет в наличии на эту дату`);
              return c;
            }
          }
          
          return { ...c, quantity: newQty };
        }
        return c;
      }).filter(Boolean);
    });
  };

  const removeFromCart = (itemId) => {
    setCart(prev => prev.filter(c => c.id !== itemId));
  };

  const clearCart = () => {
    setCart([]);
    setShowClearCartAlert(false);
    toast.success("Корзина очищена");
  };

  const confirmRemoveFromCart = (item) => {
    setItemToRemove(item);
  };

  const handleRemoveConfirmed = () => {
    if (itemToRemove) {
      removeFromCart(itemToRemove.id);
      toast.success(`${itemToRemove.name} удалено из корзины`);
      setItemToRemove(null);
    }
  };

  const getCartItemQuantity = (ids) => {
    const idsArray = Array.isArray(ids) ? ids : [ids];
    return cart
      .filter(c => idsArray.includes(c.id))
      .reduce((sum, c) => sum + c.quantity, 0);
  };

  const totalItems = cart.reduce((sum, c) => sum + c.quantity, 0);
  
  // Calculate days from date range
  const shootDays = dateRange.from && dateRange.to 
    ? Math.max(1, Math.ceil((dateRange.to - dateRange.from) / (1000 * 60 * 60 * 24)) + 1)
    : dateRange.from ? 1 : 0;
  
  const totalPrice = cart.reduce((sum, c) => sum + (c.quantity * shootDays * (c.rent_price || 0)), 0);

  // Group equipment by name
  const groupedEquipment = equipment.reduce((acc, eq) => {
    const key = eq.name?.toLowerCase().trim();
    if (!key) return acc;
    if (!acc[key]) {
      acc[key] = {
        ...eq,
        ids: [eq.id],
        stock: eq.stock || 1
      };
    } else {
      acc[key].ids.push(eq.id);
      acc[key].stock += (eq.stock || 1);
    }
    return acc;
  }, {});

  const filteredEquipment = Object.values(groupedEquipment)
    .filter(eq => {
      const matchesSearch = eq.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        eq.sheet_id?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === "all" || eq.category === categoryFilter;
      const matchesOwner = ownerFilters.length === 0 || ownerFilters.includes(eq.owner);
      const matchesHidden = showHidden || !eq.is_hidden;
      return matchesSearch && matchesCategory && matchesOwner && matchesHidden;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "name":
          return (a.name || "").localeCompare(b.name || "", "ru");
        case "name_desc":
          return (b.name || "").localeCompare(a.name || "", "ru");
        case "category":
          return (a.category || "").localeCompare(b.category || "", "ru");
        case "stock":
          return (b.stock || 1) - (a.stock || 1);
        case "stock_asc":
          return (a.stock || 1) - (b.stock || 1);
        default:
          return 0;
      }
    });

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col">
      <SyncStatusBar />
      
      <div className="flex-1 flex">
        {/* Main Content */}
        <div className="flex-1 px-4 sm:px-6 py-8 sm:py-12 max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Каталог техники
          </h1>
          <p className="text-slate-500 mt-1">
            Выберите оборудование для съёмки
            {lastUpdated && (
              <span className="ml-2 text-xs text-slate-400">
                • Обновлено {format(lastUpdated, "d MMM yyyy, HH:mm", { locale: ru })}
              </span>
            )}
          </p>
        </div>

        {/* Shoot Info */}
        <div className="mb-8 p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Shoot Title */}
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Название съёмки</label>
              <Input
                placeholder="Введите название..."
                value={shootTitle}
                onChange={(e) => setShootTitle(e.target.value)}
                className="bg-slate-50"
              />
            </div>
            
            {/* Date Range */}
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Даты</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start gap-2 bg-slate-50 text-left">
                    <CalendarIcon className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                    <span className="truncate">
                      {dateRange.from ? (
                        dateRange.to ? (
                          `${format(dateRange.from, "d MMM", { locale: ru })} – ${format(dateRange.to, "d MMM yyyy", { locale: ru })}`
                        ) : (
                          format(dateRange.from, "d MMMM yyyy", { locale: ru })
                        )
                      ) : (
                        "Выберите даты"
                      )}
                    </span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="range"
                    selected={dateRange}
                    onSelect={(range) => setDateRange(range || { from: undefined, to: undefined })}
                    locale={ru}
                    numberOfMonths={1}
                    className="sm:hidden"
                  />
                  <Calendar
                    mode="range"
                    selected={dateRange}
                    onSelect={(range) => setDateRange(range || { from: undefined, to: undefined })}
                    locale={ru}
                    numberOfMonths={2}
                    className="hidden sm:block"
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            {/* Location */}
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Локация</label>
              <Input
                placeholder="Адрес или место..."
                value={shootLocation}
                onChange={(e) => setShootLocation(e.target.value)}
                className="bg-slate-50"
              />
            </div>
            
            {/* Responsible */}
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Ответственный</label>
              <Input
                placeholder="Имя ответственного..."
                value={shootResponsible}
                onChange={(e) => setShootResponsible(e.target.value)}
                className="bg-slate-50"
              />
            </div>
          </div>
        </div>

        {/* Category Tiles */}
        <div className="mb-3">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-medium text-slate-500 uppercase">Категория</span>
          </div>
          <div className="flex flex-wrap gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setCategoryFilter("all")}
              className={`flex-shrink-0 px-4 py-2 rounded-xl font-medium transition-all ${
                categoryFilter === "all"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200"
                  : "bg-white text-slate-600 border border-slate-200 hover:border-indigo-300 hover:text-indigo-600"
              }`}
            >
              Все
            </button>
            {categories
              .filter(cat => {
                const setting = categorySettings[cat];
                return !setting || !setting.is_private || isAdmin;
              })
              .map(cat => {
              const catDisplay = getCategoryDisplay(cat);
              const CatIcon = catDisplay.icon;
              const isActive = categoryFilter === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap ${
                    isActive
                      ? `${catDisplay.color} shadow-md`
                      : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <CatIcon className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate max-w-32">{catDisplay.label}</span>
                </button>
              );
            })}
          </div>
        </div>



        {/* Search & Controls */}
        <div className="mb-6 flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 sm:gap-4">
          <div className="relative flex-1 min-w-0 sm:min-w-48 sm:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Поиск по названию или ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-white border-slate-200"
            />
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full sm:w-44 bg-white">
                <ArrowUpDown className="w-4 h-4 mr-2 text-slate-400" />
                <SelectValue placeholder="Сортировка" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">По названию А-Я</SelectItem>
                <SelectItem value="name_desc">По названию Я-А</SelectItem>
                <SelectItem value="category">По категории</SelectItem>
                <SelectItem value="stock">По наличию ↓</SelectItem>
                <SelectItem value="stock_asc">По наличию ↑</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Switch
                id="showId"
                checked={showSheetId}
                onCheckedChange={setShowSheetId}
              />
              <label htmlFor="showId" className="text-sm text-slate-600 cursor-pointer flex items-center gap-1">
                <Hash className="w-3.5 h-3.5" />
                ID
              </label>
            </div>

            {isAdmin && (
              <div className="flex items-center gap-2">
                <Switch
                  id="showHidden"
                  checked={showHidden}
                  onCheckedChange={setShowHidden}
                />
                <label htmlFor="showHidden" className="text-sm text-slate-600 cursor-pointer flex items-center gap-1">
                  <EyeOff className="w-3.5 h-3.5" />
                  Скрытые
                </label>
              </div>
            )}
          </div>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
          </div>
        ) : filteredEquipment.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Package className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-1">Ничего не найдено</h3>
            <p className="text-slate-500">
              Попробуйте изменить фильтры
            </p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block bg-white rounded-xl border border-slate-200 overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 text-left text-sm text-slate-600">
                  <tr>
                    <th className="px-4 py-3 font-medium">Название</th>
                    <th className="px-4 py-3 font-medium">Категория</th>
                    <th className="px-4 py-3 font-medium text-right">Цена/день</th>
                    <th className="px-4 py-3 font-medium text-center">В наличии</th>
                    <th className="px-4 py-3 font-medium text-center">Действие</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredEquipment.map(eq => {
                    const inCart = getCartItemQuantity(eq.id);
                    const catDisplay = getCategoryDisplay(eq.category);
                    const CatIcon = catDisplay.icon;
                    const stock = eq.stock || 1;
                    const booked = getBookedQuantity(eq.ids || [eq.id]);
                    const available = getAvailableQuantity(eq);
                    const displayAvailable = stock - booked - inCart;
                    
                    return (
                      <tr key={eq.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            {eq.is_hidden && (
                              <EyeOff className="w-3.5 h-3.5 text-slate-400" title="Скрыто" />
                            )}
                            <Link 
                              to={createPageUrl(`EquipmentDetail?id=${eq.id}`)}
                              className={`font-medium hover:text-indigo-600 transition-colors ${eq.is_hidden ? "text-slate-400" : "text-slate-900"}`}
                            >
                              {eq.name}
                            </Link>
                            <Link
                              to={createPageUrl(`EquipmentDetail?id=${eq.id}`)}
                              className="text-slate-400 hover:text-indigo-600"
                            >
                              <Eye className="w-4 h-4" />
                            </Link>
                            {isAdmin && (
                              <button
                                onClick={() => setEditingEquipment(eq)}
                                className="text-slate-400 hover:text-indigo-600"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                          {showSheetId && eq.sheet_id && (
                            <div className="text-xs text-slate-400 mt-0.5 font-mono">
                              ID: {eq.sheet_id}
                            </div>
                          )}
                          {eq.description && (
                            <div className="text-sm text-slate-500 truncate max-w-xs">{eq.description}</div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <Badge className={catDisplay.color}>
                            <CatIcon className="w-3 h-3 mr-1" />
                            {catDisplay.label}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {eq.rent_price > 0 ? (
                            <span className="text-indigo-600 font-medium">{eq.rent_price.toLocaleString()} ₽</span>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <div className="flex flex-col items-center">
                            <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full font-medium text-sm ${displayAvailable > 0 ? "bg-indigo-50 text-indigo-700" : "bg-red-50 text-red-600"}`}>
                              {displayAvailable}
                            </span>
                            {booked > 0 && (
                              <span className="text-xs text-slate-400 mt-1">из {stock}</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center">
                          {inCart > 0 ? (
                            <div className="flex items-center justify-center gap-1">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => updateCartQuantity(eq.id, -1)}
                              >
                                <Minus className="w-3 h-3" />
                              </Button>
                              <span className="w-8 text-center font-medium">{inCart}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => updateCartQuantity(eq.id, 1)}
                                disabled={available <= 0}
                              >
                                <Plus className="w-3 h-3" />
                              </Button>
                            </div>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => addToCart(eq)}
                              disabled={available <= 0}
                              className={available > 0 ? "text-indigo-600 border-indigo-200 hover:bg-indigo-50" : "text-slate-400"}
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              {available > 0 ? "Добавить" : "Нет в наличии"}
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-3 pb-48">
              {filteredEquipment.map(eq => {
                const inCart = getCartItemQuantity(eq.id);
                const catDisplay = getCategoryDisplay(eq.category);
                const CatIcon = catDisplay.icon;
                const stock = eq.stock || 1;
                const booked = getBookedQuantity(eq.ids || [eq.id]);
                const available = getAvailableQuantity(eq);
                const displayAvailable = stock - booked - inCart;

                return (
                  <div key={eq.id} className="bg-white rounded-xl border border-slate-200 p-4">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          {eq.is_hidden && (
                            <EyeOff className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          )}
                          <span className={`font-medium ${eq.is_hidden ? "text-slate-400" : "text-slate-900"}`}>
                            {eq.name}
                          </span>
                        </div>
                        {showSheetId && eq.sheet_id && (
                          <div className="text-xs text-slate-400 mt-0.5 font-mono">ID: {eq.sheet_id}</div>
                        )}
                        <div className="mt-1.5">
                          <Badge className={`${catDisplay.color} text-xs`}>
                            <CatIcon className="w-3 h-3 mr-1" />
                            {catDisplay.label}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex flex-col items-center flex-shrink-0">
                        <span className={`inline-flex items-center justify-center w-10 h-10 rounded-full font-semibold ${displayAvailable > 0 ? "bg-indigo-50 text-indigo-700" : "bg-red-50 text-red-600"}`}>
                          {displayAvailable}
                        </span>
                        <span className="text-xs text-slate-400 mt-0.5">в наличии</span>
                      </div>
                    </div>

                    {eq.description && (
                      <p className="text-sm text-slate-500 mb-3 line-clamp-2">{eq.description}</p>
                    )}

                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <Link
                          to={createPageUrl(`EquipmentDetail?id=${eq.id}`)}
                          className="text-slate-400 hover:text-indigo-600 p-2"
                        >
                          <Eye className="w-5 h-5" />
                        </Link>
                        {isAdmin && (
                          <button
                            onClick={() => setEditingEquipment(eq)}
                            className="text-slate-400 hover:text-indigo-600 p-2"
                          >
                            <Pencil className="w-5 h-5" />
                          </button>
                        )}
                      </div>

                      {inCart > 0 ? (
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-9 w-9"
                            onClick={() => updateCartQuantity(eq.id, -1)}
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <span className="w-8 text-center font-semibold text-lg">{inCart}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-9 w-9"
                            onClick={() => updateCartQuantity(eq.id, 1)}
                            disabled={available <= 0}
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <Button
                          onClick={() => addToCart(eq)}
                          disabled={available <= 0}
                          className={available > 0 ? "bg-indigo-600 hover:bg-indigo-700" : "bg-slate-200 text-slate-400"}
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          {available > 0 ? "Добавить" : "Нет"}
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
        </div>

        {/* Right Sidebar - Cart (Desktop) */}
        {cart.length > 0 && (
          <div className="hidden lg:flex w-80 flex-shrink-0 border-l border-slate-200 bg-white sticky top-16 h-[calc(100vh-64px)] flex-col">
            <div className="p-3 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-indigo-600" />
                <h2 className="font-semibold text-slate-900 text-sm">Корзина</h2>
                <span className="ml-auto bg-indigo-600 text-white text-xs px-2 py-0.5 rounded-full font-medium">
                  {totalItems}
                </span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              <div className="space-y-2">
                {cart.map(item => {
                  const itemTotal = item.quantity * shootDays * (item.rent_price || 0);
                  return (
                    <div key={item.id} className="p-2 bg-slate-50 rounded-lg">
                      <div className="flex items-start justify-between gap-1 mb-1">
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-slate-900 text-xs leading-tight truncate">{item.name}</p>
                          <p className="text-xs text-slate-500">
                            {item.quantity} шт. × {shootDays} дн.
                            {item.rent_price > 0 && ` × ${item.rent_price} ₽`}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-5 w-5 text-slate-400 hover:text-red-500 flex-shrink-0"
                          onClick={() => confirmRemoveFromCart(item)}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => updateCartQuantity(item.id, -1)}
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-6 text-center font-medium text-xs">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => updateCartQuantity(item.id, 1)}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                        {itemTotal > 0 && (
                          <span className="text-xs font-medium text-indigo-600">
                            {itemTotal.toLocaleString()} ₽
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-3 border-t border-slate-200 space-y-2">
              {shootDays > 0 && (
                <div className="text-xs text-slate-500 text-center">
                  {shootDays} {shootDays === 1 ? 'день' : shootDays < 5 ? 'дня' : 'дней'}
                </div>
              )}
              {totalPrice > 0 && (
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-600">Итого:</span>
                  <span className="font-bold text-indigo-600">{totalPrice.toLocaleString()} ₽</span>
                </div>
              )}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  className="flex-shrink-0 h-9 w-9"
                  onClick={() => setShowClearCartAlert(true)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
                <Button 
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 h-9 text-sm"
                  disabled={isSubmitting}
                  onClick={async () => {
                    const missing = [];
                    if (!shootTitle.trim()) missing.push("название съёмки");
                    if (!dateRange.from) missing.push("дату");
                    if (!shootResponsible.trim()) missing.push("ответственного");
                    
                    if (missing.length > 0) {
                      toast.error(`Заполните: ${missing.join(", ")}`);
                      return;
                    }
                    
                    setIsSubmitting(true);
                    setSubmitProgress({ current: 0, total: cart.length + 1 });
                    
                    try {
                      const shoot = await base44.entities.Shoot.create({
                        title: shootTitle.trim(),
                        date: format(dateRange.from, "yyyy-MM-dd"),
                        end_date: dateRange.to ? format(dateRange.to, "yyyy-MM-dd") : format(dateRange.from, "yyyy-MM-dd"),
                        location: shootLocation.trim() || undefined,
                        responsible: shootResponsible.trim()
                      });
                      setSubmitProgress({ current: 1, total: cart.length + 1 });
                      
                      // Bulk create equipment in one call
                      const equipmentData = cart.map(item => ({
                        shoot: shoot.id,
                        equipment: item.id,
                        equipment_name: item.name,
                        quantity: item.quantity,
                        days: shootDays,
                        rent_price: item.rent_price || 0
                      }));
                      await base44.entities.ShootEquipment.bulkCreate(equipmentData);
                      setSubmitProgress({ current: cart.length + 1, total: cart.length + 1 });
                      
                      toast.success("Заявка оформлена!");
                      window.scrollTo(0, 0);
                      navigate(createPageUrl(`ShootDetail?id=${shoot.id}`));
                    } catch (e) {
                      toast.error("Ошибка при оформлении заявки");
                      setIsSubmitting(false);
                    }
                  }}
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  {isSubmitting ? `${submitProgress.current}/${submitProgress.total}` : "Оформить"}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      <EditEquipmentDialog
        equipment={editingEquipment}
        open={!!editingEquipment}
        onClose={() => setEditingEquipment(null)}
        onSaved={() => {
          loadInitialData().then(() => {
            setEquipment(getLocalData("equipment"));
          });
        }}
      />

      {/* Clear Cart Alert */}
      <AlertDialog open={showClearCartAlert} onOpenChange={setShowClearCartAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Очистить корзину?</AlertDialogTitle>
            <AlertDialogDescription>
              Все товары будут удалены из корзины. Это действие нельзя отменить.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction onClick={clearCart} className="bg-red-600 hover:bg-red-700">
              Очистить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Remove Item Alert */}
      <AlertDialog open={!!itemToRemove} onOpenChange={(open) => !open && setItemToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить из корзины?</AlertDialogTitle>
            <AlertDialogDescription>
              {itemToRemove?.name} будет удалён из корзины.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction onClick={handleRemoveConfirmed} className="bg-red-600 hover:bg-red-700">
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Mobile Cart Overlay */}
      {cart.length > 0 && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-2xl z-40 rounded-t-2xl">
          <div className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center">
                  <ShoppingCart className="w-4 h-4 text-indigo-600" />
                </div>
                <div>
                  <span className="font-semibold text-slate-900">{totalItems} поз.</span>
                  {totalPrice > 0 && (
                    <span className="ml-2 text-indigo-600 font-bold">{totalPrice.toLocaleString()} ₽</span>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-slate-400"
                onClick={() => setShowClearCartAlert(true)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>

            {isSubmitting && (
              <div className="mb-3">
                <Progress value={(submitProgress.current / submitProgress.total) * 100} className="h-2" />
                <p className="text-xs text-slate-500 text-center mt-1">
                  Сохранение {submitProgress.current} из {submitProgress.total}...
                </p>
              </div>
            )}
            <Button 
              className="w-full bg-indigo-600 hover:bg-indigo-700 h-12 text-base font-medium"
              disabled={isSubmitting}
              onClick={async () => {
                const missing = [];
                if (!shootTitle.trim()) missing.push("название съёмки");
                if (!dateRange.from) missing.push("дату");
                if (!shootResponsible.trim()) missing.push("ответственного");

                if (missing.length > 0) {
                  toast.error(`Заполните: ${missing.join(", ")}`);
                  return;
                }

                setIsSubmitting(true);
                setSubmitProgress({ current: 0, total: cart.length + 1 });

                try {
                  const shoot = await base44.entities.Shoot.create({
                    title: shootTitle.trim(),
                    date: format(dateRange.from, "yyyy-MM-dd"),
                    end_date: dateRange.to ? format(dateRange.to, "yyyy-MM-dd") : format(dateRange.from, "yyyy-MM-dd"),
                    location: shootLocation.trim() || undefined,
                    responsible: shootResponsible.trim()
                  });
                  setSubmitProgress({ current: 1, total: cart.length + 1 });

                  // Bulk create equipment in one call
                  const equipmentData = cart.map(item => ({
                    shoot: shoot.id,
                    equipment: item.id,
                    equipment_name: item.name,
                    quantity: item.quantity,
                    days: shootDays,
                    rent_price: item.rent_price || 0
                  }));
                  await base44.entities.ShootEquipment.bulkCreate(equipmentData);
                  setSubmitProgress({ current: cart.length + 1, total: cart.length + 1 });

                  toast.success("Заявка оформлена!");
                  window.scrollTo(0, 0);
                  navigate(createPageUrl(`ShootDetail?id=${shoot.id}`));
                } catch (e) {
                  toast.error("Ошибка при оформлении заявки");
                  setIsSubmitting(false);
                }
              }}
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              {isSubmitting ? "Сохранение..." : "Оформить заявку"}
            </Button>
          </div>
        </div>
      )}
      </div>
      );
      }