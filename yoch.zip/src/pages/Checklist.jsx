import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Loader2, CheckCircle2, Package, Camera, Aperture, Box, Wifi, Zap, Wrench, CircleDot, Sun, HardDrive, Cable, Mic, Target, Layers, Anchor, Grip, Plug, Monitor, Briefcase, Backpack, Contrast, Orbit } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useSync } from "@/components/sync/SyncManager";
import SyncStatusBar from "@/components/sync/SyncStatusBar";

const ICON_MAP = {
  "Камеры": Camera,
  "Оптика": Aperture,
  "Свет": Zap,
  "Звук": Wifi,
  "Grip": Box,
  "Прочее": Wrench
};

const COLOR_MAP = {
  "Камеры": "bg-blue-100 text-blue-700 border-blue-200",
  "Оптика": "bg-purple-100 text-purple-700 border-purple-200",
  "Свет": "bg-amber-100 text-amber-700 border-amber-200",
  "Звук": "bg-emerald-100 text-emerald-700 border-emerald-200",
  "Grip": "bg-slate-100 text-slate-700 border-slate-200",
  "Прочее": "bg-pink-100 text-pink-700 border-pink-200"
};

export default function Checklist() {
  const urlParams = new URLSearchParams(window.location.search);
  const shootId = urlParams.get("id");
  
  const [shoot, setShoot] = useState(null);
  const [shootEquipment, setShootEquipment] = useState([]);
  const [equipmentCatalog, setEquipmentCatalog] = useState([]);
  const [categorySettings, setCategorySettings] = useState([]);
  const [checklistStatuses, setChecklistStatuses] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const { isOnline, getLocalData, createRecord, updateRecord, loadInitialData } = useSync();

  useEffect(() => {
    loadData();
  }, [shootId]);



  const loadData = async () => {
    setIsLoading(true);
    try {
      await loadInitialData();
      
      const shoots = getLocalData("shoots");
      const shootData = shoots.find(s => s.id === shootId);
      setShoot(shootData);
      
      const allEquipment = getLocalData("shootEquipment");
      const shootEq = allEquipment.filter(se => se.shoot === shootId);
      setShootEquipment(shootEq);
      
      const catalog = getLocalData("equipment");
      setEquipmentCatalog(catalog);

      let statusesData = [];
      if (isOnline) {
        try {
          statusesData = await base44.entities.EquipmentChecklistStatus.filter({ shoot: shootId });
          // Save to local
          localStorage.setItem("pwa_checklist_statuses", JSON.stringify(statusesData));
        } catch (e) {
          // Load from local if online fetch fails
          const cached = localStorage.getItem("pwa_checklist_statuses");
          statusesData = cached ? JSON.parse(cached) : [];
        }
      } else {
        // Offline mode
        const cached = localStorage.getItem("pwa_checklist_statuses");
        statusesData = cached ? JSON.parse(cached) : [];
      }

      const categorySettingsData = await base44.entities.CategorySettings.list();
      setCategorySettings(categorySettingsData);

      const statusMap = {};
      statusesData.forEach(status => {
        const key = `${status.shoot_equipment}_${status.item_index || 0}`;
        statusMap[key] = status;
      });
      setChecklistStatuses(statusMap);
    } catch (e) {
      toast.error("Ошибка загрузки данных");
    }
    setIsLoading(false);
  };

  const handleToggle = async (shootEquipmentId, itemIndex, field) => {
    try {
      const key = `${shootEquipmentId}_${itemIndex}`;
      const existingStatus = checklistStatuses[key];
      const newValue = !existingStatus?.[field];
      const dateField = field === 'received' ? 'received_date' : 'returned_date';
      
      const updatedStatus = {
        ...existingStatus,
        shoot_equipment: shootEquipmentId,
        shoot: shootId,
        item_index: itemIndex,
        [field]: newValue,
        [dateField]: newValue ? new Date().toISOString() : null
      };

      // Update local state immediately
      setChecklistStatuses(prev => ({
        ...prev,
        [key]: updatedStatus
      }));

      // Sync with server
      if (isOnline) {
        try {
          if (existingStatus?.id && !existingStatus.id.startsWith("temp_")) {
            await base44.entities.EquipmentChecklistStatus.update(existingStatus.id, {
              [field]: newValue,
              [dateField]: newValue ? new Date().toISOString() : null
            });
          } else {
            const created = await base44.entities.EquipmentChecklistStatus.create({
              shoot_equipment: shootEquipmentId,
              shoot: shootId,
              item_index: itemIndex,
              [field]: newValue,
              [dateField]: newValue ? new Date().toISOString() : null
            });
            updatedStatus.id = created.id;
            setChecklistStatuses(prev => ({
              ...prev,
              [key]: updatedStatus
            }));
          }
          
          // Save to cache
          const allStatuses = Object.values({ ...checklistStatuses, [key]: updatedStatus });
          localStorage.setItem("pwa_checklist_statuses", JSON.stringify(allStatuses));
        } catch (e) {
          console.error("Sync error:", e);
        }
      } else {
        // Save locally when offline
        const allStatuses = Object.values({ ...checklistStatuses, [key]: updatedStatus });
        localStorage.setItem("pwa_checklist_statuses", JSON.stringify(allStatuses));
      }
    } catch (e) {
      toast.error("Ошибка обновления");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!shoot) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col items-center justify-center">
        <p className="text-slate-500 mb-4">Заявка не найдена</p>
        <Link to={createPageUrl("Home")}>
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Назад
          </Button>
        </Link>
      </div>
    );
  }

  const getCategoryDisplay = (categoryKey) => {
    const setting = categorySettings.find(s => s.category_key === categoryKey);
    if (setting) {
      const iconMap = {
        Camera: Camera,
        Aperture: Aperture,
        Box: Box,
        Wifi: Wifi,
        Zap: Zap,
        Wrench: Wrench,
        Package: Package,
        CircleDot: CircleDot,
        Sun: Sun,
        HardDrive: HardDrive,
        Cable: Cable,
        Mic: Mic,
        Target: Target,
        Layers: Layers,
        Anchor: Anchor,
        Grip: Grip,
        Plug: Plug,
        Monitor: Monitor,
        Briefcase: Briefcase,
        Backpack: Backpack,
        Contrast: Contrast,
        Orbit: Orbit
      };
      const colorMap = {
        Blue: "bg-blue-100 text-blue-700",
        Purple: "bg-purple-100 text-purple-700",
        Violet: "bg-violet-100 text-violet-700",
        Amber: "bg-amber-100 text-amber-700",
        Yellow: "bg-yellow-100 text-yellow-700",
        Green: "bg-green-100 text-green-700",
        Emerald: "bg-emerald-100 text-emerald-700",
        Teal: "bg-teal-100 text-teal-700",
        Cyan: "bg-cyan-100 text-cyan-700",
        Sky: "bg-sky-100 text-sky-700",
        Indigo: "bg-indigo-100 text-indigo-700",
        Fuchsia: "bg-fuchsia-100 text-fuchsia-700",
        Pink: "bg-pink-100 text-pink-700",
        Rose: "bg-rose-100 text-rose-700",
        Red: "bg-red-100 text-red-700",
        Orange: "bg-orange-100 text-orange-700",
        Slate: "bg-slate-100 text-slate-700",
        Gray: "bg-gray-100 text-gray-700",
        Zinc: "bg-zinc-100 text-zinc-700",
        Stone: "bg-stone-100 text-stone-700"
      };
      return {
        label: setting.label,
        icon: iconMap[setting.icon] || Package,
        color: colorMap[setting.color] || "bg-slate-100 text-slate-700"
      };
    }
    const IconComponent = ICON_MAP[categoryKey] || Package;
    return {
      label: categoryKey,
      icon: IconComponent,
      color: COLOR_MAP[categoryKey] || "bg-slate-100 text-slate-700"
    };
  };

  // Calculate total items including multiple IDs and quantities
  let totalItems = 0;
  shootEquipment.forEach(eq => {
    const catalogItem = equipmentCatalog.find(e => e.id === eq.equipment);
    const sheetIds = catalogItem?.sheet_id?.split(',').map(s => s.trim()).filter(Boolean) || [];
    const itemCount = Math.max(sheetIds.length, eq.quantity || 1);
    totalItems += itemCount;
  });

  const receivedCount = Object.values(checklistStatuses).filter(s => s.received).length;
  const returnedCount = Object.values(checklistStatuses).filter(s => s.returned).length;

  // Group equipment by category
  const groupedEquipment = shootEquipment.reduce((acc, eq) => {
    const catalogItem = equipmentCatalog.find(e => e.id === eq.equipment);
    const category = catalogItem?.category || 'Прочее';
    if (!acc[category]) acc[category] = [];
    acc[category].push(eq);
    return acc;
  }, {});

  const categories = Object.keys(groupedEquipment).sort();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      <SyncStatusBar />
      
      {/* Mobile Header - Sticky */}
      <div className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200 lg:hidden">
        <div className="px-4 py-3">
          <Link 
            to={createPageUrl("ShootDetail") + `?id=${shootId}`}
            className="inline-flex items-center text-sm text-slate-600 hover:text-slate-900 mb-2"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Назад
          </Link>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-base font-bold text-slate-900">Чек-лист</h1>
              <p className="text-xs text-slate-500">{shoot.title}</p>
            </div>
            <div className="flex gap-2">
              <div className="text-center px-2 py-1 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-600 font-medium">{receivedCount}</p>
                <p className="text-[10px] text-blue-500">взято</p>
              </div>
              <div className="text-center px-2 py-1 bg-emerald-50 rounded-lg">
                <p className="text-xs text-emerald-600 font-medium">{returnedCount}</p>
                <p className="text-[10px] text-emerald-500">сдано</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-3 sm:px-6 py-4 sm:py-8">
        {/* Desktop Header */}
        <div className="hidden lg:block mb-6">
          <Link 
            to={createPageUrl("ShootDetail") + `?id=${shootId}`}
            className="inline-flex items-center text-sm text-slate-500 hover:text-slate-700 mb-4 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Назад к заявке
          </Link>

          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-6 shadow-lg">
            <div className="flex items-start justify-between gap-4">
              <div>
                <Badge className="bg-white/20 text-white border-white/30 font-mono text-xs mb-3">
                  #{shootId?.slice(-6).toUpperCase()}
                </Badge>
                <h1 className="text-2xl font-bold text-white mb-1">
                  Чек-лист оборудования
                </h1>
                <p className="text-emerald-100">{shoot.title}</p>
                {shoot.date && (
                  <p className="text-emerald-100 text-sm mt-1">
                    {format(new Date(shoot.date), "d MMMM yyyy", { locale: ru })}
                  </p>
                )}
              </div>
              <div className="flex gap-3">
                <div className="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-3 text-center">
                  <p className="text-2xl font-bold text-white">{receivedCount}/{totalItems}</p>
                  <p className="text-xs text-emerald-100">Получено</p>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-3 text-center">
                  <p className="text-2xl font-bold text-white">{returnedCount}/{totalItems}</p>
                  <p className="text-xs text-emerald-100">Сдано</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Equipment List - Grouped by Category */}
        <div className="space-y-4">
          {categories.map((categoryKey) => {
            const items = groupedEquipment[categoryKey];
            const categoryDisplay = getCategoryDisplay(categoryKey);
            const CategoryIcon = categoryDisplay?.icon;
            
            return (
              <div key={categoryKey} className="bg-white rounded-xl border border-slate-200/60 shadow-sm overflow-hidden">
                {/* Category Header */}
                <div className={`px-4 py-2.5 border-b ${categoryDisplay.color} flex items-center gap-2`}>
                  {CategoryIcon && <CategoryIcon className="w-4 h-4" />}
                  <h2 className="font-semibold text-sm">{categoryDisplay.label}</h2>
                  <span className="text-xs opacity-75">({items.length})</span>
                </div>

                {/* Equipment Items */}
                <div className="divide-y divide-slate-100">
                  {items.map((eq) => {
                    // Find all IDs for items with same name
                    const allIds = equipmentCatalog
                      .filter(e => e.name?.toLowerCase().trim() === eq.equipment_name?.toLowerCase().trim())
                      .map(e => e.sheet_id)
                      .filter(Boolean);
                    
                    const quantity = eq.quantity || 1;
                    const totalCount = Math.max(allIds.length, quantity);
                    
                    return (
                      <div key={eq.id} className="p-3 hover:bg-slate-50 transition-colors">
                        {/* Equipment Name */}
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium text-slate-900 text-sm flex-1">
                            {eq.equipment_name}
                          </h3>
                          {totalCount > 1 && (
                            <Badge variant="outline" className="text-xs">
                              ×{totalCount}
                            </Badge>
                          )}
                        </div>

                        {/* Checklist Items */}
                        <div className="space-y-2">
                          {Array.from({ length: totalCount }).map((_, idx) => {
                            const sheetId = allIds[idx] || '';
                            const key = `${eq.id}_${idx}`;
                            const status = checklistStatuses[key];
                            const allReceived = status?.received;
                            const allReturned = status?.returned;
                            
                            return (
                              <div key={idx} className="flex items-center gap-2">
                                {/* ID Badge */}
                                <div className="font-mono text-xs text-slate-600 bg-slate-100 px-2 py-1 rounded min-w-[60px] text-center">
                                  {sheetId || `#${idx + 1}`}
                                </div>
                                
                                {/* Checkboxes */}
                                <div className="flex gap-2 flex-1">
                                  <label 
                                    className={`flex items-center gap-2 px-3 py-2 rounded-lg border-2 transition-all cursor-pointer flex-1 ${
                                      allReceived 
                                        ? 'border-blue-500 bg-blue-50/80 shadow-sm' 
                                        : 'border-slate-200 hover:border-blue-300 hover:bg-blue-50/30'
                                    }`}
                                  >
                                    <Checkbox
                                      checked={allReceived || false}
                                      onCheckedChange={() => handleToggle(eq.id, idx, 'received')}
                                      className="data-[state=checked]:bg-blue-600"
                                    />
                                    <div className="flex-1 min-w-0">
                                      <p className={`text-xs font-medium ${allReceived ? 'text-blue-900' : 'text-slate-700'}`}>
                                        Взял
                                      </p>
                                      {status?.received_date && (
                                        <p className="text-[10px] text-blue-600/80">
                                          {format(new Date(status.received_date), "HH:mm", { locale: ru })}
                                        </p>
                                      )}
                                    </div>
                                  </label>

                                  <label 
                                    className={`flex items-center gap-2 px-3 py-2 rounded-lg border-2 transition-all cursor-pointer flex-1 ${
                                      allReturned 
                                        ? 'border-emerald-500 bg-emerald-50/80 shadow-sm' 
                                        : allReceived
                                          ? 'border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/30'
                                          : 'border-slate-200 bg-slate-50/50 cursor-not-allowed'
                                    }`}
                                  >
                                    <Checkbox
                                      checked={allReturned || false}
                                      onCheckedChange={() => handleToggle(eq.id, idx, 'returned')}
                                      disabled={!allReceived}
                                      className="data-[state=checked]:bg-emerald-600"
                                    />
                                    <div className="flex-1 min-w-0">
                                      <p className={`text-xs font-medium ${allReturned ? 'text-emerald-900' : 'text-slate-700'}`}>
                                        Сдал
                                      </p>
                                      {status?.returned_date && (
                                        <p className="text-[10px] text-emerald-600/80">
                                          {format(new Date(status.returned_date), "HH:mm", { locale: ru })}
                                        </p>
                                      )}
                                    </div>
                                  </label>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}