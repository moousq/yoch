import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Save, Package, FileSpreadsheet, Upload, Database, Trash2, AlertTriangle, Plus, Pencil, Palette, Download } from "lucide-react";
import { toast } from "sonner";
import SyncGoogleSheet from "@/components/equipment/SyncGoogleSheet";
import ImportEquipmentCSV from "@/components/equipment/ImportEquipmentCSV";
import CategoryEditor, { ICONS, COLORS } from "@/components/categories/CategoryEditor";
import ExportSettings from "@/components/settings/ExportSettings";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";

export default function Settings() {
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showGoogleSync, setShowGoogleSync] = useState(false);
  const [showCSVImport, setShowCSVImport] = useState(false);
  const [equipmentCount, setEquipmentCount] = useState(0);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [savedSheetUrl, setSavedSheetUrl] = useState("");
  const [showCategoryEditor, setShowCategoryEditor] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState(null);
  const [categoryEquipmentCount, setCategoryEquipmentCount] = useState(0);
  const [clearCategoryFromEquipment, setClearCategoryFromEquipment] = useState(false);
  const [activeTab, setActiveTab] = useState("database");
  const [clearProgress, setClearProgress] = useState({ current: 0, total: 0 });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const equipment = await base44.entities.EquipmentCatalog.list();
      setEquipmentCount(equipment.length);
      
      const savedSettings = await base44.entities.CategorySettings.list();
      setCategories(savedSettings);

      const user = await base44.auth.me();
      if (user?.google_sheet_url) {
        setSavedSheetUrl(user.google_sheet_url);
      }
    } catch (error) {
      console.error("Failed to load data:", error);
    }
    setIsLoading(false);
  };

  const loadCategories = async () => {
    try {
      const savedSettings = await base44.entities.CategorySettings.list();
      setCategories(savedSettings);
    } catch (error) {
      console.error("Failed to load categories:", error);
    }
  };

  const handleSaveCategory = async (formData, existingId) => {
    try {
      if (existingId) {
        await base44.entities.CategorySettings.update(existingId, formData);
        toast.success("Категория обновлена");
      } else {
        await base44.entities.CategorySettings.create(formData);
        toast.success("Категория создана");
      }
      loadCategories();
    } catch (error) {
      toast.error("Ошибка сохранения");
    }
  };

  const handleDeleteCategory = async () => {
    if (!categoryToDelete) return;
    try {
      // Delete category settings
      await base44.entities.CategorySettings.delete(categoryToDelete.id);
      
      // If user chose to clear category from equipment
      if (clearCategoryFromEquipment && categoryEquipmentCount > 0) {
        const equipment = await base44.entities.EquipmentCatalog.filter({ 
          category: categoryToDelete.category_key 
        });
        
        // Clear category from all equipment in parallel batches
        const BATCH_SIZE = 10;
        for (let i = 0; i < equipment.length; i += BATCH_SIZE) {
          const batch = equipment.slice(i, i + BATCH_SIZE);
          await Promise.all(batch.map(eq => 
            base44.entities.EquipmentCatalog.update(eq.id, { category: '' })
          ));
        }
      }
      
      toast.success("Категория удалена");
      setShowDeleteDialog(false);
      setCategoryToDelete(null);
      setCategoryEquipmentCount(0);
      setClearCategoryFromEquipment(false);
      loadCategories();
      loadData();
    } catch (error) {
      toast.error("Ошибка удаления");
    }
  };

  const openEditCategory = (cat) => {
    setEditingCategory(cat);
    setShowCategoryEditor(true);
  };

  const openNewCategory = () => {
    setEditingCategory(null);
    setShowCategoryEditor(true);
  };

  const getIconComponent = (iconName) => {
    const found = ICONS.find(i => i.name === iconName);
    return found ? found.icon : Package;
  };

  const getColorConfig = (colorName) => {
    return COLORS.find(c => c.name === colorName) || COLORS.find(c => c.name === "Slate");
  };

  const handleCSVImport = async (records) => {
    for (const record of records) {
      await base44.entities.EquipmentCatalog.create({
        name: record.name,
        category: record.category,
        description: record.description,
        stock: record.quantity || 1
      });
    }
    toast.success(`Импортировано ${records.length} позиций`);
    loadData();
  };

  const handleSynced = () => {
    loadData();
  };

  const handleClearDatabase = async () => {
    setIsClearing(true);
    try {
      const equipment = await base44.entities.EquipmentCatalog.list();
      setClearProgress({ current: 0, total: equipment.length });
      
      for (let i = 0; i < equipment.length; i++) {
        await base44.entities.EquipmentCatalog.delete(equipment[i].id);
        setClearProgress({ current: i + 1, total: equipment.length });
      }
      
      toast.success("База оборудования очищена");
      setShowClearDialog(false);
      setClearProgress({ current: 0, total: 0 });
      loadData();
    } catch (error) {
      toast.error("Ошибка очистки базы");
    }
    setIsClearing(false);
  };

  const handleSaveSheetUrl = async () => {
    try {
      await base44.auth.updateMe({ google_sheet_url: savedSheetUrl });
      toast.success("URL сохранён");
    } catch (error) {
      toast.error("Ошибка сохранения");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Настройки</h1>
          <p className="text-slate-500 mt-1">Управление базой оборудования и категориями</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="database" className="gap-2">
              <Database className="w-4 h-4" />
              База данных
            </TabsTrigger>
            <TabsTrigger value="categories" className="gap-2">
              <Palette className="w-4 h-4" />
              Категории
            </TabsTrigger>
            <TabsTrigger value="export" className="gap-2">
              <Download className="w-4 h-4" />
              Экспорт
            </TabsTrigger>
          </TabsList>

          {/* Database Tab */}
          <TabsContent value="database" className="space-y-6">
            {/* Stats */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center">
                    <Package className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500">Всего оборудования</p>
                    <p className="text-2xl font-bold text-slate-900">{equipmentCount}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Google Sheets Sync */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-green-600" />
                  Google Sheets
                </CardTitle>
                <CardDescription>
                  Синхронизируйте оборудование с Google таблицей
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>URL таблицы (для быстрого доступа)</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="https://docs.google.com/spreadsheets/d/..."
                      value={savedSheetUrl}
                      onChange={(e) => setSavedSheetUrl(e.target.value)}
                      className="flex-1"
                    />
                    <Button variant="outline" onClick={handleSaveSheetUrl}>
                      <Save className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <Button 
                  onClick={() => setShowGoogleSync(true)}
                  className="bg-green-600 hover:bg-green-700 gap-2"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  Синхронизировать
                </Button>
              </CardContent>
            </Card>

            {/* CSV Import */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Upload className="w-5 h-5 text-indigo-600" />
                  Импорт CSV
                </CardTitle>
                <CardDescription>
                  Загрузите файл CSV с данными об оборудовании
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline"
                  onClick={() => setShowCSVImport(true)}
                  className="gap-2"
                >
                  <Upload className="w-4 h-4" />
                  Загрузить файл
                </Button>
              </CardContent>
            </Card>

            {/* Danger Zone */}
            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  Опасная зона
                </CardTitle>
                <CardDescription>
                  Необратимые действия с базой данных
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="destructive"
                  onClick={() => setShowClearDialog(true)}
                  className="gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Очистить базу оборудования
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Categories Tab */}
          <TabsContent value="categories" className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-slate-500">
                {categories.length} {categories.length === 1 ? "категория" : "категорий"}
              </p>
              <Button 
                onClick={openNewCategory}
                className="bg-indigo-600 hover:bg-indigo-700 gap-2"
              >
                <Plus className="w-4 h-4" />
                Добавить
              </Button>
            </div>

            {categories.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-slate-500">
                  <Package className="w-10 h-10 mx-auto mb-3 text-slate-300" />
                  <p>Нет категорий</p>
                  <p className="text-sm mt-1">Создайте первую категорию</p>
                  <Button 
                    onClick={openNewCategory}
                    className="mt-4 bg-indigo-600 hover:bg-indigo-700 gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Добавить категорию
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {categories.map((cat) => {
                  const IconComponent = getIconComponent(cat.icon);
                  const colorConfig = getColorConfig(cat.color);
                  
                  return (
                    <Card key={cat.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl ${colorConfig?.bg} ${colorConfig?.text} flex items-center justify-center flex-shrink-0`}>
                            <IconComponent className="w-6 h-6" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-slate-900">{cat.label}</p>
                              {cat.is_hidden && (
                                <span className="text-xs px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">Скрыта</span>
                              )}
                              {cat.is_private && (
                                <span className="text-xs px-1.5 py-0.5 rounded bg-amber-100 text-amber-700">Приватная</span>
                              )}
                            </div>
                            <p className="text-sm text-slate-500 font-mono">{cat.category_key}</p>
                          </div>

                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditCategory(cat)}
                              className="text-slate-500 hover:text-indigo-600"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={async () => {
                                setCategoryToDelete(cat);
                                // Count equipment with this category
                                const equipment = await base44.entities.EquipmentCatalog.filter({ 
                                  category: cat.category_key 
                                });
                                setCategoryEquipmentCount(equipment.length);
                                setShowDeleteDialog(true);
                              }}
                              className="text-slate-500 hover:text-red-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Export Tab */}
          <TabsContent value="export">
            <ExportSettings />
          </TabsContent>
        </Tabs>
      </div>

      <SyncGoogleSheet 
        open={showGoogleSync} 
        onClose={() => setShowGoogleSync(false)} 
        onSynced={handleSynced}
        defaultSheetUrl={savedSheetUrl}
      />
      
      <ImportEquipmentCSV 
        open={showCSVImport} 
        onClose={() => setShowCSVImport(false)} 
        onImport={handleCSVImport}
      />

      {/* Clear Database Dialog */}
      <Dialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Очистить базу оборудования?
            </DialogTitle>
            <DialogDescription>
              Это действие удалит все {equipmentCount} позиций оборудования. Это действие нельзя отменить.
            </DialogDescription>
          </DialogHeader>
          {isClearing && clearProgress.total > 0 && (
            <div className="space-y-2">
              <Progress value={(clearProgress.current / clearProgress.total) * 100} className="h-2" />
              <p className="text-sm text-slate-500 text-center">
                Удалено {clearProgress.current} из {clearProgress.total}
              </p>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowClearDialog(false)} disabled={isClearing}>
              Отмена
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleClearDatabase}
              disabled={isClearing}
            >
              {isClearing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Удалить всё
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Category Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={(open) => {
        setShowDeleteDialog(open);
        if (!open) {
          setClearCategoryFromEquipment(false);
          setCategoryEquipmentCount(0);
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" />
              Удалить категорию?
            </DialogTitle>
            <DialogDescription>
              {categoryEquipmentCount > 0 ? (
                <div className="space-y-3 pt-2">
                  <p>Категория "{categoryToDelete?.label}" используется в {categoryEquipmentCount} позициях оборудования.</p>
                  <div className="flex items-start gap-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                    <input
                      type="checkbox"
                      id="clearCategory"
                      checked={clearCategoryFromEquipment}
                      onChange={(e) => setClearCategoryFromEquipment(e.target.checked)}
                      className="mt-1"
                    />
                    <label htmlFor="clearCategory" className="text-sm text-amber-800 cursor-pointer">
                      Также очистить категорию у всего оборудования (оборудование останется, но без категории)
                    </label>
                  </div>
                </div>
              ) : (
                <p>Категория "{categoryToDelete?.label}" будет удалена. Оборудование не использует эту категорию.</p>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Отмена
            </Button>
            <Button variant="destructive" onClick={handleDeleteCategory}>
              Удалить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Category Editor */}
      <CategoryEditor
        open={showCategoryEditor}
        onClose={() => {
          setShowCategoryEditor(false);
          setEditingCategory(null);
        }}
        category={editingCategory}
        onSave={handleSaveCategory}
      />
    </div>
  );
}