
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Package, Menu, X, Settings, ClipboardList, User, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { SyncProvider } from "@/components/sync/SyncManager";
import ServiceWorkerRegistration from "@/components/sync/ServiceWorkerRegistration";
import { Toaster } from "@/components/ui/sonner";
import { base44 } from "@/api/base44Client";
import NotificationBell from "@/components/notifications/NotificationBell";

function LayoutContent({ children, currentPageName }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkAdmin = async () => {
      try {
        const user = await base44.auth.me();
        setIsAdmin(user?.role === "admin");
      } catch (e) {
        setIsAdmin(false);
      }
    };
    checkAdmin();
  }, []);

  const navItems = [
    { name: "Заявки", icon: ClipboardList, page: "Home" },
    { name: "Техника", icon: Package, page: "Equipment" },
    ...(isAdmin ? [
      { name: "Настройки", icon: Settings, page: "Settings" }
    ] : []),
    { name: "Профиль", icon: User, page: "Profile" }
  ];

  const handleLogout = () => {
    base44.auth.logout();
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link 
              to={createPageUrl("Home")} 
              className="flex items-center gap-2"
            >
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692dbd18a0e661c829bf29c7/f3f298813_logogreen2x.png" 
                alt="YOCH" 
                className="w-9 h-9 rounded-xl object-cover"
              />
              <span className="font-bold text-slate-900 text-lg hidden sm:block">
                                    YOCH Base
                                    <span className="ml-1.5 text-[10px] font-medium text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-full align-top">beta</span>
                                  </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden sm:flex items-center gap-1">
              <NotificationBell />
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = currentPageName === item.page || 
                  (currentPageName === "ShootDetail" && item.page === "Home");
                
                return (
                  <Link key={item.page} to={createPageUrl(item.page)}>
                    <Button 
                      variant="ghost" 
                      className={`
                        gap-2 font-medium transition-all
                        ${isActive 
                          ? "bg-indigo-50 text-indigo-700 hover:bg-indigo-100" 
                          : "text-slate-600 hover:text-slate-900"
                        }
                      `}
                    >
                      <Icon className="w-4 h-4" />
                      {item.name}
                    </Button>
                  </Link>
                );
              })}
              <Button 
                variant="ghost" 
                onClick={handleLogout}
                className="gap-2 font-medium text-slate-600 hover:text-red-600"
              >
                <LogOut className="w-4 h-4" />
                Выйти
              </Button>
            </div>

            {/* Mobile Actions */}
            <div className="flex items-center gap-1 sm:hidden">
              <NotificationBell />
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden border-t border-slate-200 bg-white">
            <div className="px-4 py-3 space-y-1">
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = currentPageName === item.page || 
                  (currentPageName === "ShootDetail" && item.page === "Home");
                
                return (
                  <Link 
                    key={item.page} 
                    to={createPageUrl(item.page)}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <div className={`
                      flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-colors
                      ${isActive 
                        ? "bg-indigo-50 text-indigo-700" 
                        : "text-slate-600 hover:bg-slate-50"
                      }
                    `}>
                      <Icon className="w-5 h-5" />
                      {item.name}
                    </div>
                  </Link>
                );
              })}
              <button 
                onClick={handleLogout}
                className="flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-colors text-slate-600 hover:bg-red-50 hover:text-red-600 w-full"
              >
                <LogOut className="w-5 h-5" />
                Выйти
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main>
        {children}
      </main>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <SyncProvider>
      <ServiceWorkerRegistration />
      <Toaster position="top-center" />
      <LayoutContent currentPageName={currentPageName}>
        {children}
      </LayoutContent>
    </SyncProvider>
  );
}
