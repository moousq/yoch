import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, CheckCircle, XCircle, Search, Loader2, Calendar, Package, ArrowRight, Plus, MapPin, User, Play, FileCheck, Ban, Trash2, Hash } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ShootsCalendar from "@/components/shoots/ShootsCalendar";
import QuickRequestForm from "@/components/requests/QuickRequestForm";

function MobileCalendarToggle({ shoots }) {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div>
      <Button
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full justify-between"
      >
        <span className="flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          Календарь съёмок
        </span>
        <span className="text-xs text-slate-400">{isOpen ? "Скрыть" : "Показать"}</span>
      </Button>
      {isOpen && (
        <div className="mt-3">
          <ShootsCalendar shoots={shoots} />
        </div>
      )}
    </div>
  );
}

const statusConfig = {
  draft: { label: "Черновик", icon: Clock, color: "text-slate-600 border-slate-200 bg-slate-50" },
  pending: { label: "Ожидает", icon: Clock, color: "text-amber-600 border-amber-200 bg-amber-50" },
  approved: { label: "Одобрено", icon: CheckCircle, color: "text-green-600 border-green-200 bg-green-50" },
  in_progress: { label: "В работе", icon: Play, color: "text-blue-600 border-blue-200 bg-blue-50" },
  completed: { label: "Завершено", icon: FileCheck, color: "text-emerald-600 border-emerald-200 bg-emerald-50" },
  rejected: { label: "Отклонено", icon: XCircle, color: "text-red-600 border-red-200 bg-red-50" },
  cancelled: { label: "Отменено", icon: Ban, color: "text-gray-600 border-gray-200 bg-gray-50" }
};

export default function Home() {
  const [shoots, setShoots] = useState([]);
  const [shootEquipment, setShootEquipment] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [selectedShoots, setSelectedShoots] = useState(new Set());
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteProgress, setDeleteProgress] = useState({ current: 0, total: 0 });

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        setIsAdmin(user?.role === "admin");
        
        const [shootsData, equipmentData] = await Promise.all([
          base44.entities.Shoot.list("-created_date"),
          base44.entities.ShootEquipment.list()
        ]);
        
        // Filter shoots: admin sees all, user sees only their own
        const filteredByUser = user?.role === "admin" 
          ? shootsData 
          : shootsData.filter(s => s.created_by === user?.email);
        
        setShoots(filteredByUser);
        setShootEquipment(equipmentData);
      } catch (e) {
        console.error(e);
      }
      setIsLoading(false);
    };
    load();
  }, []);

  const getEquipmentCount = (shootId) => {
    return shootEquipment.filter(se => se.shoot === shootId).length;
  };

  const getShootTotal = (shootId, shoot) => {
    const items = shootEquipment.filter(se => se.shoot === shootId);
    // Calculate days from shoot dates if available
    let shootDays = 1;
    if (shoot?.date && shoot?.end_date && shoot.end_date !== shoot.date) {
      const start = new Date(shoot.date);
      const end = new Date(shoot.end_date);
      shootDays = Math.max(1, Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1);
    }
    return items.reduce((sum, eq) => {
      const days = eq.days || shootDays;
      return sum + ((eq.quantity || 1) * days * (eq.rent_price || 0));
    }, 0);
  };

  const formatDateRange = (startDate, endDate) => {
    if (!startDate) return null;
    const start = new Date(startDate);
    if (!endDate || startDate === endDate) {
      return format(start, "d MMM yyyy", { locale: ru });
    }
    const end = new Date(endDate);
    if (start.getMonth() === end.getMonth() && start.getFullYear() === end.getFullYear()) {
      return `${format(start, "d", { locale: ru })}–${format(end, "d MMM yyyy", { locale: ru })}`;
    }
    return `${format(start, "d MMM", { locale: ru })} – ${format(end, "d MMM yyyy", { locale: ru })}`;
  };

  const filteredShoots = shoots.filter(shoot => {
    const matchesSearch = shoot.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shoot.responsible?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || shoot.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const pendingCount = shoots.filter(s => s.status === "pending" || !s.status).length;

  const toggleSelect = (shootId, e) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedShoots(prev => {
      const newSet = new Set(prev);
      if (newSet.has(shootId)) {
        newSet.delete(shootId);
      } else {
        newSet.add(shootId);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    if (selectedShoots.size === filteredShoots.length) {
      setSelectedShoots(new Set());
    } else {
      setSelectedShoots(new Set(filteredShoots.map(s => s.id)));
    }
  };

  const handleBulkDelete = async () => {
    setIsDeleting(true);
    const shootIds = Array.from(selectedShoots);
    setDeleteProgress({ current: 0, total: shootIds.length });

    try {
      // Collect all equipment to delete
      const allEqToDelete = shootEquipment.filter(se => shootIds.includes(se.shoot));

      // Delete equipment in parallel batches
      const BATCH_SIZE = 10;
      for (let i = 0; i < allEqToDelete.length; i += BATCH_SIZE) {
        const batch = allEqToDelete.slice(i, i + BATCH_SIZE);
        await Promise.all(batch.map(eq => base44.entities.ShootEquipment.delete(eq.id)));
      }

      // Delete shoots in parallel batches
      for (let i = 0; i < shootIds.length; i += BATCH_SIZE) {
        const batch = shootIds.slice(i, i + BATCH_SIZE);
        await Promise.all(batch.map(id => base44.entities.Shoot.delete(id)));
        setDeleteProgress({ current: Math.min(i + BATCH_SIZE, shootIds.length), total: shootIds.length });
      }

      setShoots(prev => prev.filter(s => !selectedShoots.has(s.id)));
      setShootEquipment(prev => prev.filter(se => !selectedShoots.has(se.shoot)));
      setSelectedShoots(new Set());
      toast.success(`Удалено ${shootIds.length} заявок`);
    } catch (e) {
      toast.error("Ошибка при удалении");
    }
    setIsDeleting(false);
    setDeleteProgress({ current: 0, total: 0 });
    setShowDeleteDialog(false);
  };

  const getShortId = (id) => {
    return id?.slice(-6).toUpperCase() || "";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-5">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              {isAdmin ? "Все заявки" : "Мои заявки"}
            </h1>
            <p className="text-slate-500 mt-1">
              {isAdmin 
                ? (pendingCount > 0 ? `${pendingCount} заявок ожидает подтверждения` : "Нет ожидающих заявок")
                : `Всего ${shoots.length} заявок`
              }
            </p>
          </div>
          <Link to={createPageUrl("Equipment")}>
            <Button className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className="w-4 h-4 mr-2" />
              Новая заявка
            </Button>
          </Link>
        </div>

        {/* Mobile Quick Form & Calendar */}
        <div className="lg:hidden mb-6 space-y-4">
          <QuickRequestForm />
          {!isLoading && shoots.length > 0 && (
            <MobileCalendarToggle shoots={shoots} />
          )}
        </div>

        {/* Two Column Layout */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left - Requests */}
          <div className="flex-1 min-w-0">
            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-3 mb-5">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Поиск по названию или ответственному..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 bg-white border-slate-200"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48 bg-white">
                  <SelectValue placeholder="Все статусы" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все статусы</SelectItem>
                  <SelectItem value="pending">Ожидает</SelectItem>
                  <SelectItem value="approved">Одобрено</SelectItem>
                  <SelectItem value="rejected">Отклонено</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Admin bulk actions */}
            {isAdmin && filteredShoots.length > 0 && (
              <div className="flex items-center gap-3 mb-4 p-3 bg-white border border-slate-200 rounded-lg">
                <Checkbox
                  checked={selectedShoots.size === filteredShoots.length && filteredShoots.length > 0}
                  onCheckedChange={toggleSelectAll}
                />
                <span className="text-sm text-slate-600">
                  {selectedShoots.size > 0 ? `Выбрано: ${selectedShoots.size}` : "Выбрать все"}
                </span>
                {selectedShoots.size > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDeleteDialog(true)}
                    className="ml-auto text-red-600 border-red-200 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Удалить ({selectedShoots.size})
                  </Button>
                )}
              </div>
            )}

            {/* Content */}
            {isLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
              </div>
            ) : filteredShoots.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-1">Нет заявок</h3>
                <p className="text-slate-500">
                  {searchTerm || statusFilter !== "all" ? "Попробуйте изменить фильтры" : "Заявки появятся здесь"}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredShoots.map(shoot => {
                  const status = shoot.status || "pending";
                  const StatusIcon = statusConfig[status]?.icon || Clock;
                  const equipmentCount = getEquipmentCount(shoot.id);
                  const totalPrice = getShootTotal(shoot.id, shoot);
                  const dateDisplay = formatDateRange(shoot.date, shoot.end_date);
                  const isSelected = selectedShoots.has(shoot.id);
                  
                  return (
                    <Link key={shoot.id} to={createPageUrl(`ShootDetail?id=${shoot.id}`)}>
                      <Card className={`group hover:shadow-md transition-all duration-200 border-slate-200/60 bg-white overflow-hidden ${isSelected ? "ring-2 ring-indigo-500" : ""}`}>
                        <CardContent className="p-5">
                          <div className="flex items-start gap-3">
                            {/* Checkbox for admin */}
                            {isAdmin && (
                              <div className="pt-1" onClick={(e) => toggleSelect(shoot.id, e)}>
                                <Checkbox checked={isSelected} />
                              </div>
                            )}
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-3 mb-2">
                                <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                                  <Hash className="w-3 h-3" />
                                  {getShortId(shoot.id)}
                                </span>
                                <Badge variant="outline" className={`${statusConfig[status]?.color} shrink-0`}>
                                  <StatusIcon className="w-3 h-3 mr-1" />
                                  {statusConfig[status]?.label}
                                </Badge>
                                {shoot.created_date && (
                                  <span className="text-xs text-slate-400">
                                    создано {format(new Date(shoot.created_date), "d MMM HH:mm", { locale: ru })}
                                  </span>
                                )}
                              </div>
                              
                              <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors truncate mb-2">
                                {shoot.title}
                              </h3>
                              
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500">
                                {dateDisplay && (
                                  <span className="flex items-center gap-1.5">
                                    <Calendar className="w-4 h-4" />
                                    {dateDisplay}
                                    {shoot.end_date && shoot.end_date !== shoot.date && (() => {
                                      const days = Math.ceil((new Date(shoot.end_date) - new Date(shoot.date)) / (1000 * 60 * 60 * 24)) + 1;
                                      const lastDigit = days % 10;
                                      const lastTwo = days % 100;
                                      let label = 'суток';
                                      if (lastTwo >= 11 && lastTwo <= 14) {
                                        label = 'суток';
                                      } else if (lastDigit === 1) {
                                        label = 'сутки';
                                      }
                                      return (
                                        <span className="text-xs text-slate-400">
                                          ({days} {label})
                                        </span>
                                      );
                                    })()}
                                  </span>
                                )}
                                {shoot.responsible && (
                                  <span className="flex items-center gap-1.5">
                                    <User className="w-4 h-4" />
                                    {shoot.responsible}
                                  </span>
                                )}
                                {shoot.location && (
                                  <span className="flex items-center gap-1.5">
                                    <MapPin className="w-4 h-4" />
                                    {shoot.location}
                                  </span>
                                )}
                                <span className="flex items-center gap-1.5">
                                  <Package className="w-4 h-4" />
                                  {equipmentCount} ед.
                                </span>
                              </div>

                              {totalPrice > 0 && (
                                <div className="mt-2 text-sm text-slate-500">
                                  Стоимость: {totalPrice.toLocaleString()} ₽
                                </div>
                              )}
                            </div>
                            
                            <ArrowRight className="w-5 h-5 text-slate-400 group-hover:text-indigo-600 transition-colors shrink-0 mt-1" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right - Calendar & Quick Form (Desktop) */}
          <div className="hidden lg:block lg:w-80 shrink-0">
            <div className="sticky top-20 space-y-4">
              <QuickRequestForm />
              {!isLoading && shoots.length > 0 && (
                <ShootsCalendar shoots={shoots} />
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Delete confirmation dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить заявки?</AlertDialogTitle>
            <AlertDialogDescription>
              Будет удалено {selectedShoots.size} заявок и всё связанное оборудование. Это действие нельзя отменить.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {isDeleting && deleteProgress.total > 0 && (
            <div className="space-y-2 py-2">
              <Progress value={(deleteProgress.current / deleteProgress.total) * 100} className="h-2" />
              <p className="text-sm text-slate-500 text-center">
                Удалено {deleteProgress.current} из {deleteProgress.total}
              </p>
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Отмена</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleBulkDelete} 
              className="bg-red-600 hover:bg-red-700"
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}