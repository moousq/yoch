import { base44 } from './base44Client';


export const syncGoogleSheet = base44.functions.syncGoogleSheet;

export const exportEquipmentList = base44.functions.exportEquipmentList;

